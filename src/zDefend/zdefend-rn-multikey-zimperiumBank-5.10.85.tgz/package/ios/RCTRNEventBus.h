

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>

@interface EventEmitter : RCTEventEmitter
@end

@interface RNEventBus : NSObject<RCTBridgeModule>

@end
