
#import "RCTRNEventBus.h"

#import <React/RCTLog.h>
#import <ZDefend/consumer_c.h>

#include <string>
#include <exception>

static NSString * string_to_nsstring(const std::string & str) {
    return [NSString stringWithCString:str.c_str() encoding:[NSString defaultCStringEncoding]];
}


@interface EventEmitter ()
@end

@implementation EventEmitter
- (NSArray<NSString *> *)supportedEvents {
    return @[@"RNEventBusSubmitForResponseEvent", @"RNEventBusListenEvent"];
}
- (void)startObserving {
    
}

- (void)stopObserving {
    
}

- (void)invalidate {
    [super invalidate];
}

- (void)addListener:(NSString *)eventName {
    
}

- (void)removeListeners:(double)count {
}

@end

@interface Context : NSObject
@property(nonatomic, weak) NSObject * owner;
@property(nonatomic, retain) NSObject * objid;
@property(nonatomic, assign) bool destroyed;
@end

@implementation Context
@end


static void dispatch_safe_async(dispatch_queue_t queue, dispatch_block_t block) {
    dispatch_async(queue, ^{
        try {
            @try {
                block();
            } @catch(NSException *exception) {
                RCTLogError(@"dispatch_safe_async: NS exception - %@", [exception debugDescription]);
            }
        } catch(std::exception &ex) {
            RCTLogError(@"dispatch_safe_async: std exception - %@", string_to_nsstring(ex.what()));
        }
    });
}

@interface RNEventBus ()
- (void) submitEventName:(NSString *) name body: (NSDictionary *) body;
@end

@implementation RNEventBus
@synthesize bridge = _bridge;
@synthesize callableJSModules = _callableJSModules;
@synthesize moduleRegistry = _moduleRegistry;

RCT_EXPORT_MODULE(RNEventBus);

static NSMutableDictionary * callers;
static NSMutableDictionary * lmap;
static long l_id;
static NSMutableDictionary * idmap;
static dispatch_once_t once;

- (id) init {
    RCTLogInfo(@"RNEventBus init");
    self = [super init];
    if(self) {
        dispatch_once(&once, ^ {
            callers = [[NSMutableDictionary alloc] init];
            lmap = [[NSMutableDictionary alloc] init];
            idmap = [[NSMutableDictionary alloc] init];
            l_id = 0;
        });
        return self;
    }
    return nil;
}

- (void) dealloc {
    @synchronized(RNEventBus.class) {
        for(id key in callers) {
            Context *ctx = [callers objectForKey:key];
            ctx.destroyed = true;
        }
        for(id key in lmap) {
            Context *ctx = [lmap objectForKey:key];
            ctx.destroyed = true;
        }
    }
}

- (void) submitEventName:(NSString *) name body: (NSDictionary *) body {
    EventEmitter * e = [[EventEmitter alloc] initWithDisabledObservation];
    e.bridge = self.bridge;
    e.callableJSModules = self.callableJSModules;
    e.moduleRegistry = self.moduleRegistry;
    [e sendEventWithName:name body:body];
}

+ (BOOL) requiresMainQueueSetup {
    return YES;
}

RCT_EXPORT_METHOD(createRNEventBus)
{
    RCTLogInfo(@"RNEventBus created!");
    
}

RCT_EXPORT_METHOD(submit:(NSString *) name details:(NSString *) details) {
    dispatch_safe_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        zdevice_event_submit(name.UTF8String, details.UTF8String);
    });
}


RCT_EXPORT_METHOD(submitForResponse:(NSString *) sid name:(NSString *) name details:(NSString *) details) {
    @synchronized(RNEventBus.class) {
        Context * ctx = [[Context alloc] init];
        ctx.owner = self;
        ctx.objid = sid;
        ctx.destroyed = false;
        [callers setObject:ctx forKey:sid];
        dispatch_safe_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            zdevice_event_submit_for_response((__bridge void *) ctx, name.UTF8String, details.UTF8String, [] (void * context, const char * event_name, const char * event_details, const char * response) {
                @synchronized(RNEventBus.class) {
                    Context * ctx = (__bridge Context *) context;
                    if (ctx.destroyed) return;
                    NSString * res = [NSString stringWithUTF8String:response];
                    RNEventBus * myself = (RNEventBus *) ctx.owner;
                    NSString * sid = (NSString *) ctx.objid;
                
                    NSDictionary * dict = @{@"eventName": string_to_nsstring(event_name),
                        @"eventDetails": string_to_nsstring(event_details),
                        @"id": sid,
                        @"response": res
                    };
                    
                    RCTLogInfo(@"submitForResponse(), firing event: %@", dict);
                    // TODO -- need to avoid using myself if its deallocated
                    [myself submitEventName:@"RNEventBusSubmitForResponseEvent" body:dict];
                    RCTLogInfo(@"submitForResponse(), event fired");
                    
                    [callers removeObjectForKey:sid];
                }
            });
        });
    }
}

RCT_EXPORT_METHOD(listen:(NSString *) name sid:(NSString *) sid callback:(RCTResponseSenderBlock) callback) {
    zdevice_event_registration_t reg;
    @synchronized(RNEventBus.class) {
        long lid = l_id ++;
        Context * ctx = [[Context alloc] init];
        ctx.owner = self;
        ctx.objid = sid;
        ctx.destroyed = false;
        [lmap setObject:ctx forKey:@(lid)];
        
        reg = zdevice_event_listen((__bridge void *) ctx, name.UTF8String, [](void * context, const char * event_name, const char * event_details, void * ctx_returner, zdevice_event_returnfunc_t returner) {

            __weak Context * ctx = (__bridge Context *) context;
            if (ctx.destroyed) return;
            __weak RNEventBus * myself = (RNEventBus *) ctx.owner;
            NSString * sid = (NSString *) ctx.objid;
            NSDictionary * dict = @{@"eventName": string_to_nsstring(event_name),
                @"eventDetails": string_to_nsstring(event_details),
                @"id": sid
            };
            RCTLogInfo(@"listen(), firing event: %@", dict);
            // TODO -- need to avoid using myself if its deallocated
            [myself submitEventName:@"RNEventBusListenEvent" body:dict];
            RCTLogInfo(@"listen(), event fired");

        });
        
        [idmap setObject:@((long) reg) forKey:@(lid)];
    }
    callback(@[@((long) reg)]);
}

RCT_EXPORT_METHOD(unlisten:(NSString *) sreg) {
    dispatch_safe_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSInteger num = [sreg integerValue];
        zdevice_event_registration_t reg = (zdevice_event_registration_t) num;
        zdevice_event_unlisten(reg);
        @synchronized(RNEventBus.class) {
            [idmap removeObjectForKey:@(num)];
        }
    });
}

@end
