package com.zdefend;

import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.annotation.NonNull;

import com.facebook.react.ReactPackage;
import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.uimanager.ViewManager;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import com.zimperium.api.v5.react_native.RNPackage;

public class ZDefendPackage implements ReactPackage {

  private native void initialize_rn();
  @NonNull
  @Override
  public List<ViewManager> createViewManagers(@NonNull ReactApplicationContext reactContext) {
    return Collections.emptyList();
  }

  @NonNull
  @Override
  public List<NativeModule> createNativeModules(@NonNull ReactApplicationContext reactContext) {
    List<NativeModule> modules = new ArrayList<>();
    System.loadLibrary("cpp1");
    initialize_rn();
    modules.add(new ZDefendUrlClassificationModule(reactContext));
    RNPackage pk = new RNPackage();
    modules.addAll(pk.createNativeModules(reactContext));

    return modules;
  }
}
