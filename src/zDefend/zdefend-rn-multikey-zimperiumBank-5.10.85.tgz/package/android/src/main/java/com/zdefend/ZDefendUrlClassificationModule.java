package com.zdefend;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.facebook.react.bridge.Arguments;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.module.annotations.ReactModule;

import com.facebook.react.modules.core.DeviceEventManagerModule;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


@ReactModule(name = ZDefendUrlClassificationModule.NAME)
public class ZDefendUrlClassificationModule extends ReactContextBaseJavaModule {
  public static final String NAME = "ZDefendUrlClassificationModule";

  private static final String sUrlClassificationEvent = "urlClassificationEvent";

  public ZDefendUrlClassificationModule(ReactApplicationContext reactContext) {
    super(reactContext);
  }

  @Override
  public void invalidate() {
    super.invalidate();
  }

  @ReactMethod
  @NonNull
  public String getName() {
    return NAME;
  }

  @Override
  public Map<String, Object> getConstants() {
    final Map<String, Object> constants = new HashMap<>();
    constants.put(sUrlClassificationEvent, sUrlClassificationEvent);
    return constants;
  }

  @ReactMethod
  public static void classifyUrlEmptyTest(@NonNull String url, Callback callback) {
    callback.invoke(url);
  }

  // Required for rn built in EventEmitter Calls.
  @ReactMethod
  public void addListener(String eventName) {

  }

  @ReactMethod
  public void removeListeners(Integer count) {

  }
}
