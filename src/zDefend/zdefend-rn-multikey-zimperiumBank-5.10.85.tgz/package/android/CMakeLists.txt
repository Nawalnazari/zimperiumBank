cmake_minimum_required(VERSION 3.4.1)

set (CMAKE_VERBOSE_MAKEFILE ON)
set (CMAKE_CXX_STANDARD 11)

set(SRC cpp-adapter.cpp)

add_library(cpp1
            SHARED
            ${SRC}
)




set(F1 ${F1} -O0 -g -DBUILD_FOR_ANDROID=1 -DANDROID_SUPPORT_FLEXIBLE_PAGE_SIZES=ON)
foreach(f IN ITEMS ${SRC})
  set_source_files_properties(${f} PROPERTIES COMPILE_OPTIONS "${F1}")
endforeach()

target_link_options(cpp1 PRIVATE "-Wl,-z,max-page-size=16384")
target_link_libraries(cpp1 PRIVATE Log)

