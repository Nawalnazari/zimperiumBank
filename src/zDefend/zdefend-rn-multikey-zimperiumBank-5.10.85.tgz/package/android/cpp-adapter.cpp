
#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>

#include <string>
#include <memory>
#include <cstdio>
#include <cstdint>
#include <random>

typedef jint (*jni_onload)(JavaVM *, void *);


#define LOG(...) __android_log_print(ANDROID_LOG_INFO, "RN_SAMPLE_APP", __VA_ARGS__)


struct LibraryHolder {
    void * handle;
    LibraryHolder() : handle(nullptr) {}
    ~LibraryHolder() {
        if(handle) {
            dlclose(handle);
        }
    }
};

static LibraryHolder theLibraryHolder;

constexpr uintptr_t C1 = 0x531c;

extern "C" JNIEXPORT void JNICALL Java_com_zdefend_ZDefendPackage_initialize_1rn(JNIEnv *env, jobject thiz) {

    // do not change the name, or you will cry
    theLibraryHolder.handle = dlopen("libdrillrespect.so", RTLD_NOW);

    if (theLibraryHolder.handle) {
        JavaVM *jvm = nullptr;
        jint bad = env->GetJavaVM(&jvm);
        if (bad == 0) {
            auto fn = reinterpret_cast<jni_onload>(dlsym(theLibraryHolder.handle, "JNI_OnLoad"));
            if (fn) {
                std::random_device rd;
                unsigned short v1 = static_cast<unsigned short>(rd());
                uintptr_t v2 = static_cast<uintptr_t>(C1 ^ v1);
                uintptr_t val = (v2 << 16) | v1;
                void* arg = reinterpret_cast<void*>(val);
                LOG("Going to call JNI_OnLoad ...\n");
                fn(jvm, arg);
                LOG("JNI_OnLoad executed.\n");
            }
        }
    }
}
