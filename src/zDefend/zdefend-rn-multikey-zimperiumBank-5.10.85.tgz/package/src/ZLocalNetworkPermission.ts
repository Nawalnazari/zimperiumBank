
import { ZLocalNetworkAuthorizationType } from './enums/ZLocalNetworkAuthorizationType';
import { ZDefendImpl } from "./zdefend/ZDefendImpl";

export type ZLocalNetworkAuthorizationCallback = (deviceStatus: ZLocalNetworkAuthorizationType) => void;

export class ZLocalNetworkPermission {

    static requestLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback) {
        ZDefendImpl.getInstance().requestLocalNetworkAuthorization(authorizationCallback);
    }

    static checkLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback) {
        ZDefendImpl.getInstance().checkLocalNetworkAuthorization(authorizationCallback);
    }
}