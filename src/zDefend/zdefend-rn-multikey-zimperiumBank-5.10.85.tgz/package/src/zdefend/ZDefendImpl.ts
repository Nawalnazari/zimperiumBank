import { ZDefendThreat } from "../zdefend_threat/ZDefendThreat";
import type { ErrorCallbackFunction, ZDeviceStatusCallback, ZDeviceStatusJsonCallback, ZLinkedFunctionCallback } from "../ZDefend";
import { ZDeviceStatus } from "../ZDeviceStatus";
import { DelayedRulesCompliance } from "../enums/DelayedRulesCompliance";
import { ZEvents, ZListener } from "../zimperium_rn_events";
import type { ZLocalNetworkAuthorizationCallback } from "../ZLocalNetworkPermission";
import { ZLocalNetworkAuthorizationType } from "../enums/ZLocalNetworkAuthorizationType";
import { ZLinkedFunctionRegistration, type ZLinkedFunction } from "../linked_function/ZLinkedFunctionRegistration";
import { ZLinkedFunctionEvent } from "../linked_function/ZLinkedFunctionEvent";
import { ZLinkedFunctionEventType } from "../enums/ZLinkedFunctionEventType";
import { ZDeviceStatusRegistration } from "../ZDeviceStatusRegistration";
import { ZDeviceStatusCompressionType } from "../enums/ZDeviceStatusCompressionType";
import { ZDeviceStatusJsonRegistration } from "../ZDeviceStatusJsonRegistration";

var Buffer = require('buffer/').Buffer

export class ZDefendImpl {
    private static instance: ZDefendImpl;
    private deviceStatusListeners: ZDeviceStatusRegistration[] = [];
    private deviceStatusJsonListeners: ZDeviceStatusJsonRegistration[] = [];
    private linkedFunctionListeners = new Map<string, ZLinkedFunctionCallback>();
    private linkedFunctionRegistrars: ZLinkedFunctionRegistration[] = []
    private lastDeviceStatus?: ZDeviceStatus;
    private funcLabelIsCalled: boolean = false;

    private constructor() { }

    public static getInstance(): ZDefendImpl {
        if (!ZDefendImpl.instance) {
            ZDefendImpl.instance = new ZDefendImpl();
            ZDefendImpl.instance.start();
        }
        return ZDefendImpl.instance;
    }

    public start(): void {
        ZListener.getInstance().start("com.zimperium.device.status", (_name: string, details: string) => {
            var status = new ZDeviceStatus(details, this.lastDeviceStatus);
            if (!this.funcLabelIsCalled && this.lastDeviceStatus == null && this.linkedFunctionListeners.size != 0) {
                for (const threat of status.activeThreats) {
                    try {
                        var jsonStr = JSON.stringify(threat.json);
                        var jsonThreat = JSON.parse(jsonStr);
                        if (jsonThreat.FUNCTION_LABEL) {
                            var linkCallback = this.linkedFunctionListeners.get(jsonThreat.FUNCTION_LABEL);
                            if (linkCallback) {
                                linkCallback!(jsonThreat.FUNCTION_LABEL, threat);
                            }
                        }
                    } catch (e) {
                        console.log(`Error parsing jsong threat $e`);
                    }
                }
            }
            this.lastDeviceStatus = status;
            this.notifiyStatusChange(this.lastDeviceStatus);
        });
        ZListener.getInstance().start("com.zimperium.sdkresponse.FUNCTION_LABEL", (_name: string, _details: string) => {
            this.funcLabelIsCalled = true;
            this.runUserFunction(_details);
            this.runUserFunctionV2(_details);
        });
        ZListener.getInstance().start("com.zimperium.sdkresponse.FUNCTION_LABEL.mitigate", (_name: string, _details: string) => {
            this.runUserFunctionV2(_details);
        });
    }

    public addDeviceStatusCallback(deviceStatusCallback: ZDeviceStatusCallback): ZDeviceStatusRegistration {
        if (this.lastDeviceStatus == undefined) {
            setTimeout(function () {
                ZEvents.submit("com.zimperium.device.request_status_update");
            }, 1000);
        }

        var deviceStatus = new ZDeviceStatusRegistration(deviceStatusCallback)
        this.deviceStatusListeners.push(deviceStatus);

        return deviceStatus;
    }

    public addDeviceStatusJsonCallback(deviceStatusJsonCallback: ZDeviceStatusJsonCallback, nonceString: String | undefined): ZDeviceStatusJsonRegistration {
        var deviceStatusJsonregistration = new ZDeviceStatusJsonRegistration(deviceStatusJsonCallback, nonceString);
        this.deviceStatusJsonListeners.push(deviceStatusJsonregistration);

        if (nonceString) {
            let nonceParams: object = {
                "nonce": nonceString,
                "synchronous": true
            }

            ZEvents.submitForResponse("com.zimperium.api.update_nonce", JSON.stringify(nonceParams), (json: string) => {
                let responseJson = JSON.parse(json);
                if (responseJson.hasOwnProperty("device_status_base64") && responseJson.hasOwnProperty("signature")) {
                    let base64: String = responseJson["device_status_base64"];
                    let base64Sig: String = responseJson["signature"];
                    if (base64.length > 0 && base64Sig.length > 0) {
                        deviceStatusJsonregistration.callback(base64, base64Sig);
                    }
                }
            });
        } else {
            if (this.lastDeviceStatus) {
                deviceStatusJsonregistration.callback(this.lastDeviceStatus?.deviceStatusBase64, this.lastDeviceStatus.deviceStatusBase64Signature);
            }
        }
        return deviceStatusJsonregistration;
    }

    public addLinkFunctionCallback(label: string, linkedFunctionCallback: ZLinkedFunctionCallback) {
        if (this.lastDeviceStatus != null) {
            for (const threat of this.lastDeviceStatus.activeThreats) {
                try {
                    var json = JSON.stringify(threat.json);
                    var details = JSON.parse(json);
                    if (details.FUNCTION_LABEL === label) {
                        linkedFunctionCallback(label, threat);
                    }
                } catch (e) {
                    console.log(`addLinkFunctionCallback: Error parsing jsong threat $e`);
                }
            }
        }
        this.linkedFunctionListeners.set(label, linkedFunctionCallback);
    }

    public addLinkFunctionCallbackV2(label: string, linkedFunction: ZLinkedFunction, mitigateLinkedFunction: ZLinkedFunction): ZLinkedFunctionRegistration {
        var registrar = new ZLinkedFunctionRegistration(undefined, label, linkedFunction, mitigateLinkedFunction)
        this.linkedFunctionRegistrars.push(registrar)
        this.checkExistingLinkedFunc(registrar);
        return registrar;
    }

    public removeLinkedFunction(registrar: ZLinkedFunctionRegistration) {
        const index = this.linkedFunctionRegistrars.indexOf(registrar);
        if (index !== -1) {
            this.linkedFunctionRegistrars.splice(index, 1);
            console.log("Removing linkedFunc: ", registrar.regId);
            if (registrar.regId && registrar.regId != 0) {
                let regIdData: object = {
                    "reg_id": registrar.regId,
                }
                ZEvents.submit("com.zimperium.sdksupport.FUNCTION_LABEL.unregister", JSON.stringify(regIdData));
                registrar.remove();
            }
        }
    }

    public removeDeviceStatusCallback(status: ZDeviceStatusRegistration) {
        const index = this.deviceStatusListeners.indexOf(status)
        if (index !== -1) {
            this.deviceStatusListeners.splice(index, 1)
        }
    }

    public removeDeviceStatusJsonCallback(status: ZDeviceStatusJsonRegistration) {
        const index = this.deviceStatusJsonListeners.indexOf(status)
        if (index !== -1) {
            this.deviceStatusJsonListeners.splice(index, 1)
        }
    }

    public setTrackingIds(tag1: string, tag2: string, errorCallback: ErrorCallbackFunction) {
        const MAX_TRACKING_ID_LENGTH: number = 128;

        const finalId1 = tag1 ?? "";
        const finalId2 = tag2 ?? "";

        if (finalId1.length > MAX_TRACKING_ID_LENGTH || finalId2.length > MAX_TRACKING_ID_LENGTH) {
            errorCallback("Tracking ID string length must be less than or equal to 128");
        } else {
            let trackingIdData: object = {
                "tracking_id_1": finalId1,
                "tracking_id_2": finalId2
            }
            ZEvents.submit("com.zimperium.zdefendx.update_tracking_id", JSON.stringify(trackingIdData));
        }
    }

    public checkForUpdate() {
        ZEvents.submit("com.zimperium.rules.check_updates");
        ZEvents.submit("com.zimperium.zdefendx.integrity.check");
    }

    public setExcludeThreatText(excludeText: boolean) {
        ZEvents.submit("com.zimperium.api.device_status.config", JSON.stringify({
            "update": {
                "exclude_text": excludeText
            }
        }));
    }

    public setExcludePolicyStatus(excludePolicyStatus: boolean) {
        ZEvents.submit("com.zimperium.api.device_status.config", JSON.stringify({
            "update": {
                "exclude_policies": excludePolicyStatus
            }
        }));
    }

    public setCompressionType(type: ZDeviceStatusCompressionType) {
        ZEvents.submit("com.zimperium.api.device_status.config", JSON.stringify({
            "update": {
                "compression": type == ZDeviceStatusCompressionType.COMPRESSION_TYPE_DEFLATE ? "deflate" : "none"
            }
        }));
    }

    public setNonce(nonce: String) {
        ZEvents.submit("com.zimperium.api.update_nonce", JSON.stringify({ "nonce": nonce }));
    }

    public activateDelayedRules(complianceType: DelayedRulesCompliance): void {
        switch (complianceType) {
            case DelayedRulesCompliance.CHINA_STORE_COMPLIANCE:
                ZEvents.submit("com.zimperium.zdefendx.activate_delayed_rules");
                break;
            case DelayedRulesCompliance.POLICY_COMPLIANCE:
                // Reserved for future policy-based compliance mode.
                break;
        }
    }

    public requestLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback) {
        ZEvents.submitForResponse("com.zimperium.sdk.local_network.permission.request", "{}", (authorization: string) => {
            authorizationCallback(ZLocalNetworkAuthorizationType.fromJson(authorization));
        });
    }

    public checkLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback) {
        ZEvents.submitForResponse("com.zimperium.sdk.local_network.permission.check_status", "{}", (authorization: string) => {
            authorizationCallback(ZLocalNetworkAuthorizationType.fromJson(authorization));
        });
    }

    private notifiyStatusChange(status: ZDeviceStatus) {
        for (let listener of this.deviceStatusListeners) {
            listener.callback(status);
        }

        if (this.deviceStatusJsonListeners.length > 0) {
            let base64: String = status.deviceStatusBase64;
            if (base64.length > 0) {
                const base64DecodedJSON = JSON.parse(Buffer.from(base64, 'base64').toString('utf-8'));
                let nonceString: String = base64DecodedJSON.nonce ?? '';
                for (let listener of this.deviceStatusJsonListeners) {
                    if (listener.nonceString == undefined || (nonceString.length > 0 && listener.nonceString != null && listener.nonceString === nonceString)) {
                        let signature: string = status.deviceStatusBase64Signature;
                        listener.callback(base64, signature);
                    }

                }
            }
        }
    }

    private runUserFunction(eventDetailsJson: string) {
        var details = JSON.parse(eventDetailsJson);
        if (Object.keys(details.threat).length > 0 && this.linkedFunctionListeners.has(details.responseArgument)) {
            ZEvents.submitForResponse("com.zimperium.threat.get", JSON.stringify({ "uuid": details.threat.uuid }), (_threat: string) => {
                var linkCallback = this.linkedFunctionListeners.get(details.responseArgument);
                linkCallback!(details.responseArgument, new ZDefendThreat(JSON.parse(_threat)));
            });
        }
    }

    private runUserFunctionV2(eventDetailsJson: string) {
        var details = JSON.parse(eventDetailsJson);
        var relatedThreats: ZDefendThreat[] = [];
        var deviceStatus = new ZDeviceStatus(JSON.stringify(details.device_status), this.lastDeviceStatus);
        var eventType = details.mitigated == true ? ZLinkedFunctionEventType.MITIGATED : ZLinkedFunctionEventType.ACTIVATED;
        var label = details.responseArgument;
        try {
            for (let sThreat of details.related_threats) {
                relatedThreats.push(new ZDefendThreat(sThreat))
            }
        } catch (e) { }

        var linkedFuncEvent = new ZLinkedFunctionEvent(label, eventType, deviceStatus, relatedThreats);
        console.log("RegislinkedFunctionRegistrars size: ", this.linkedFunctionRegistrars.length);
        for (let registrar of this.linkedFunctionRegistrars) {
            if (registrar.label === label && !registrar.deregistered) {
                // ensure this registration ID is included in the event registrations list, this avoids getting duplicate events in some circumstances
                var registrations = details.registrations;
                if (details && Array.isArray(registrations)) {
                    const eventRegs: number[] = registrations.filter((num: any) => typeof num === 'number');
                    if (eventRegs.includes(registrar.regId!)) {
                        if (details.mitigated) {
                            registrar.mitigateLinkedFunction(linkedFuncEvent)
                        } else {
                            registrar.linkedFunction(linkedFuncEvent)
                        }
                    }
                }
            }
        }
    }

    private checkExistingLinkedFunc(registrar: ZLinkedFunctionRegistration) {
        var req = JSON.stringify({ "label": registrar.label });
        ZEvents.submitForResponse('com.zimperium.sdksupport.FUNCTION_LABEL.register', req, (details: string) => {
            try {
                const data = JSON.parse(details);
                if (Object.keys(data).length > 0) {
                    registrar.regId = data.reg_id;

                    var relatedThreats: ZDefendThreat[] = [];
                    for (let threat of data.related_threats) {
                        var zThreat = new ZDefendThreat(threat);
                        relatedThreats.push(zThreat);
                    }
                    if (relatedThreats.length > 0) {
                        var deviceStatus = new ZDeviceStatus(JSON.stringify(data.device_status), this.lastDeviceStatus);
                        var linkedFunc = registrar.linkedFunction;
                        var linkedFuncEvent = new ZLinkedFunctionEvent(registrar.label, ZLinkedFunctionEventType.ACTIVATED, deviceStatus, relatedThreats);
                        linkedFunc(linkedFuncEvent);
                    }
                }
            } catch (e) { }
        })
    };

}


