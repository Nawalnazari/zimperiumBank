/// The device status handler registration object returned from ZDefend#addDeviceStatusCallback(zDeviceStatusCallback).

import type { ZDeviceStatusCallback } from "./ZDefend";
import { ZDefendImpl } from "./zdefend/ZDefendImpl";

/// This object can be used to de-register the handler when device status updates are no longer required.
export class ZDeviceStatusRegistration {
    /// The zDeviceStatusCallback for this registration.
    public callback: ZDeviceStatusCallback;

    constructor(callback: ZDeviceStatusCallback) {
        this.callback = callback;
    }

    /// Remove the device status handler from receiving device status change events.
    deregister(): void {
        ZDefendImpl.getInstance().removeDeviceStatusCallback(this);
    }
}
