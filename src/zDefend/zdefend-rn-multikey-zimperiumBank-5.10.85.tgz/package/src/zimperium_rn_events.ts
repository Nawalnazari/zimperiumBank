
import { NativeEventEmitter, NativeModules } from 'react-native';
import type { EmitterSubscription } from 'react-native';
const { RNEventBus } = NativeModules;
import { LogBox } from 'react-native';
LogBox.ignoreLogs(['new NativeEventEmitter']); // Ignore log notification by message, the event bus works, newer version of React still throws

type result1arg_t = (value: string) => void;
type result2arg_t = (name: string, extra: string) => void;

export class ZEvents {

    static eventEmitter = new NativeEventEmitter(NativeModules.RNEventBus);
    static eventListenListener: EmitterSubscription;
    static eventSubmitForResponseListener: EmitterSubscription;
    static initialized: boolean = false;
    static gid: number = 0;
    static lmap: { [id: string]: result2arg_t } = {};
    static lmap2: { [id: string]: string } = {};
    static srmap: { [id: string]: result1arg_t } = {};

    static startup() {
        if (ZEvents.initialized == false) {
            ZEvents.eventListenListener = ZEvents.eventEmitter.addListener('RNEventBusListenEvent', (event) => {
                console.log("ZEvents RNEventBusListenEvent " + event);
                let func = ZEvents.lmap[event.id];
                if (func == undefined) {
                    console.log("BLAAARGH func is undefined!");
                } else {
                    func(event.eventName, event.eventDetails);
                }
            });

            ZEvents.eventSubmitForResponseListener = ZEvents.eventEmitter.addListener('RNEventBusSubmitForResponseEvent', (event) => {
                let func = ZEvents.srmap[event.id];
                if (func == undefined) {
                    console.log("BLAAARGH func is undefined!");
                } else {
                    func(event.response);
                    delete ZEvents.srmap[event.id];
                }
            });

            ZEvents.initialized = true;
        }
    }

    static shutdown() {
        if (ZEvents.initialized) {
            ZEvents.eventListenListener.remove();
        }
    }

    static listen(name: string, result: result1arg_t, callback: result2arg_t): void {
        ZEvents.startup();
        let id = ZEvents.gid++;
        let sid = id.toString();
        ZEvents.lmap[sid] = callback;
        RNEventBus.listen(name, sid, (res: string) => {
            ZEvents.lmap2[res] = sid;
            result(res);
        });
    }

    static submitForResponse(name: string, details: string, result: result1arg_t): void {
        ZEvents.startup();
        let id = ZEvents.gid++;
        let sid = id.toString();
        ZEvents.srmap[sid] = result;
        RNEventBus.submitForResponse(sid, name, details);
    }

    static submit(name: string, details: string = "{}"): void {
        ZEvents.startup();
        RNEventBus.submit(name, details);
    }

    static unlisten(id: string) {
        console.log("unlisten(): " + id);
        RNEventBus.unlisten(id);
        let sid = ZEvents.lmap2[id];
        if (sid !== undefined) {
            delete ZEvents.lmap[sid];
            delete ZEvents.lmap2[id];
        }
    }
}

// helper class for listening

export class ZListener {
    private static listenerInstance: ZListener;

    private constructor() { }

    public static getInstance(): ZListener {
        if (!ZListener.listenerInstance) {
            ZListener.listenerInstance = new ZListener();
        }

        return ZListener.listenerInstance;
    }

    ids: string[] = [];
    results: { [id: string]: result2arg_t } = {};

    start(name: string, _result: result2arg_t): void {
        if (this.results[name] != undefined) {
            console.log("refusing to add this listener: " + name + ". There is already registered listener for that event!");
            return;
        }
        this.results[name] = _result;
        ZEvents.listen(name, (value: string) => {
            console.log("listener registration id = " + value);
            this.ids.push(value);
        }, (name: string, details: string) => {
            let fn = this.results[name];
            if (fn == undefined) {
                console.log("blaaargh! fn is undefined!");
            } else {
                fn(name, details);
            }
        });
    }

}
