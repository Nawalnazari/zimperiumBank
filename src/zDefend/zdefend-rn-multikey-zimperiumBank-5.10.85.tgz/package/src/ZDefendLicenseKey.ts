import { ZDefendLicenseKeyNames } from "./enums/ZDefendLicenseKeyNames";
import { ZEvents } from "./zimperium_rn_events";

export class ZDefendLicenseKey {
    static selectLicenseKey(name: ZDefendLicenseKeyNames): void {
        let i = ZDefendLicenseKeyNames.getIndex(name);
        ZEvents.submit('com.zimperium.api.license_key.name.select', JSON.stringify({ 'index': i }));
    }
}