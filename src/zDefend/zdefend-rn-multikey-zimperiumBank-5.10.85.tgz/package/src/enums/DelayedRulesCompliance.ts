/**
 * Compliance modes for delayed rule activation.
 */
export enum DelayedRulesCompliance {
  /**
   * China store compliance mode.
   */
  CHINA_STORE_COMPLIANCE,

  /**
   * Reserved for future policy-based compliance mode.
   */
  POLICY_COMPLIANCE,
}
