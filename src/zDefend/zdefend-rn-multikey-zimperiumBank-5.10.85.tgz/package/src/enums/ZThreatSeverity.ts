/**
 * The possible threat severity values.
 */
export enum ZThreatSeverity {
  HIDDEN = "HIDDEN",
  LOW = "LOW",
  IMPORTANT = "IMPORTANT",
  CRITICAL = "CRITICAL",
}

export namespace ZThreatSeverity {
  export function fromString(level: string): ZThreatSeverity {
    const enumValues = Object.values(ZThreatSeverity) as string[];
    if (enumValues.includes(level)) {
      return level as ZThreatSeverity;
    }
    return ZThreatSeverity.HIDDEN;
  }
}