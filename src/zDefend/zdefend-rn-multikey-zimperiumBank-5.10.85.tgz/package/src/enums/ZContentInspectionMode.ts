/**
 *  The possible content inspection modes returned from ZDefend#getContentInspectionMode).
 */
export enum ZContentInspectionMode {
    PHISHING = 'PHISHING',
    CONTENT_FILTERING = 'CONTENT_FILTERING',
    DISABLED = 'DISABLED'
}

export namespace ZContentInspectionMode {
    export function fromString(type: string): ZContentInspectionMode {
        const enumValues = Object.values(ZContentInspectionMode) as string[];
        if (enumValues.includes(type)) {
            return type as ZContentInspectionMode;
        }
        return ZContentInspectionMode.DISABLED;
    }
}