/**
 *  The possible last login error values returned from ZDeviceStatus#lastLoginError.
 */

export enum ZLoginError {
  LOGGED_IN = 'LOGGED_IN',
  LICENSE_EXPIRED = 'LICENSE_EXPIRED',
  LICENSE_INVALID = 'LICENSE_INVALID',
  CONNECTION_ERROR = 'CONNECTION_ERROR',
  LICENSE_LIMITED = 'LICENSE_LIMITED',
  SERVER_ERROR = 'SERVER_ERROR',
  CLIENT_ERROR = 'CLIENT_ERROR',
  NONE = 'NONE'
}

export namespace ZLoginError {
  export function fromString(error: string): ZLoginError {
    const enumValues = Object.values(ZLoginError) as string[];
    if (enumValues.includes(error)) {
      return error as ZLoginError;
    }
    return ZLoginError.NONE;
  }
}
