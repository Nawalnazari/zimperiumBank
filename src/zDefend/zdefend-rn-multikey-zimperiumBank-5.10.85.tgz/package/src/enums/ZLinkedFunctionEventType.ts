/**
 * The possible event types for a ZLinkedFunctionEvent.
 */
export enum ZLinkedFunctionEventType {
    /**
     * The event is a new activated linked function.
     */
    ACTIVATED,
    /**
     * The event is the mitigation of a previous active linked function.
     */
    MITIGATED
}