/**
 * Type possible ZDeviceStatus compression type values, see ZDeviceStatus#setCompressionType.
 */
export enum ZDeviceStatusCompressionType {
    COMPRESSION_TYPE_NONE,
    COMPRESSION_TYPE_DEFLATE
}