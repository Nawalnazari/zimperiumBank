/**
 * The possible ZDefend policy types.
 */


export enum ZDefendPolicyType {
  APP_SETTINGS = 'App Settings',
  PHISHING = 'Phishing',
  PRIVACY = 'Privacy',
  THREAT = 'Threat',
  KNOX = 'Knox',
}

export namespace ZDefendPolicyType {
  export function fromString(type: string): ZDefendPolicyType {
    const enumValues = Object.values(ZDefendPolicyType) as string[];
    if (enumValues.includes(type)) {
      return type as ZDefendPolicyType;
    }
    return ZDefendPolicyType.THREAT;
  }
}

