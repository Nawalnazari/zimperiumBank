/**
 * The possible request types for ZDefend#getZLog.
 * Use ZLOG_ALL to request all log messages.
 */

export enum ZLogType {
  NORMAL = "NORMAL",
  PHISHING = "PHISHING",
  VPN = "VPN",
  RULE_STATE = "RULE_STATE",
  RULE_DOWNLOAD = "RULE_DOWNLOAD",
  RULE_RUN = "RULE_RUN",
}

export namespace ZLogType {
  export function fromString(type: string): ZLogType {
    const enumValues = Object.values(ZLogType) as string[];
    if (enumValues.includes(type)) {
      return type as ZLogType;
    }
    return ZLogType.NORMAL;
  }
}