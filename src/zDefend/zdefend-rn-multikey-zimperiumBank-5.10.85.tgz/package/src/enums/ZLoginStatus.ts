export enum ZLoginStatus {
  LOGGED_OUT = 'logged_out',
  LOGGED_IN = 'logged_in',
  IN_PROGRESS = "authenticating",
  EMBEDDED = "embedded",
  UNKNOWN = 'unknown',
}

export namespace ZLoginStatus {
  export function fromString(status: string): ZLoginStatus {
    const enumValues = Object.values(ZLoginStatus) as string[];
    if (enumValues.includes(status)) {
      return status as ZLoginStatus;
    }
    console.log(`ZLoginStatus: ${status}`);
    return ZLoginStatus.UNKNOWN;
  }
}
