/**
 * The possible setRuleLevel values, see ZDefendDeveloper#setRuleLevel.
 */
export enum ZDefendRuleLevel {
  BETA = 'beta',
  PRODUCTION = 'production'
}

export namespace ZDefendRuleLevel {
  export function fromString(level: string): ZDefendRuleLevel {
    const enumValues = Object.values(ZDefendRuleLevel) as string[];
    if (enumValues.includes(level)) {
      return level as ZDefendRuleLevel;
    }
    return ZDefendRuleLevel.PRODUCTION;
  }
}

