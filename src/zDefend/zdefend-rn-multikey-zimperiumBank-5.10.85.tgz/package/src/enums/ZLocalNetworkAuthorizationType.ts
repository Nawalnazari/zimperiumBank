
export enum ZLocalNetworkAuthorizationType {
    // Local network permission has never been requested.
    ZLOCALNETWORK_AUTHORIZATION_NOT_ASKED = 0,
    // User has denied local network permission
    ZLOCALNETWORK_AUTHORIZATION_DENIED = 1,
    // User has granted local network permission
    ZLOCALNETWORK_AUTHORIZATION_ALLOWED = 2,
    // Need Bonjour sevice && NSLocalNetworkUsageDescription plist
    ZLOCALNETWORK_AUTHORIZATION_ERROR = 3,
}


export namespace ZLocalNetworkAuthorizationType {
    export function fromJson(authorization: string): ZLocalNetworkAuthorizationType {
        let auth = JSON.parse(authorization);
        const authorizationType = auth.error ? 3 : (auth?.authorized ?? 0) as ZLocalNetworkAuthorizationType;
        return authorizationType;
    }
}