import { ZThreatSeverity } from '../enums/ZThreatSeverity';

/**
 * ZDefendThreat contains all of the information needed to determine what threat was encountered.
 * There are also methods for retrieving the localized threat names and descriptions in human readable format.
 * See ZDeviceStatus.
 */
export class ZDefendThreat {
  private _appName: string = "";
  private _attackTime: Date = new Date();
  private _internalName: string = "";
  private _internalThreatID: number = -1;
  private _isMitigated: boolean = false;
  private _isSimulated: boolean = false;
  private _json: object = {};
  private _localizedAlertText: string = "";
  private _localizedAlertTextHtml: string = "";
  private _localizedDetails: string = "";
  private _localizedDetailsHtml: string = "";
  private _localizedName: string = "";
  private _localizedResolution: string = "";
  private _packageName: string = "";
  private _severity: ZThreatSeverity = ZThreatSeverity.HIDDEN;
  private _SSID: string = "";
  private _url: string = "";
  private _UUID: string = "";
  private _vector: string = "";
  private _malwareFamily: string = "";
  private _malwareName: string = "";
  private _profileName: string = "";
  private _sideloadedAppDeveloper: string = "";
  private _localizedAlertButtonLink: string = "";
  private _localizedAlertButtonText: string = "";

  constructor(jsonThreat: any) {
    if (JSON.stringify(jsonThreat) != "{}") {
      var forensicJson = JSON.parse(jsonThreat.forensicJson);

      var serverOOCDetail = forensicJson.server_ooc_detail ?? {};
      var serverSuspiciousIPADetail = forensicJson.server_suspicious_ipa_detail ?? {};

      this._appName =
        forensicJson.app_name ??
        forensicJson.Process ??
        forensicJson.Application ??
        forensicJson.SideloadedAppName ??
        serverOOCDetail.app_name ??
        serverSuspiciousIPADetail.app_name ??
        '';

      this._attackTime = jsonThreat.threatTime !== undefined && jsonThreat.threatTime !== 0
        ? new Date(jsonThreat.threatTime * 1000)
        : new Date();
      this._malwareName = forensicJson.MalwareThreatName ?? "";
      this._malwareFamily = this._malwareName.split(".")[0] ?? "";

      var profileDetails = forensicJson.server_untrusted_profile_detail ?? {};
      if (Object.keys(profileDetails).length === 0) {
        profileDetails = forensicJson.server_suspicious_profile_detail ?? {};
      }
      this._profileName = profileDetails.profile_name ?? "";

      this._sideloadedAppDeveloper = forensicJson.SideloadedAppDeveloper ?? "";
      if (jsonThreat.lang_description) {
        this._internalName = jsonThreat.lang_description.internalLocalizationName;
        this._localizedAlertText = this._replaceHtml(jsonThreat.lang_description.deviceAlert);
        this._localizedAlertTextHtml = jsonThreat.lang_description.deviceAlert;
        this._localizedDetails = this._replaceHtml(jsonThreat.lang_description.deviceDetailV5);
        this._localizedDetailsHtml = jsonThreat.lang_description.deviceDetailV5;
        this._localizedName = jsonThreat.lang_description.deviceName ?? jsonThreat.lang_description.internalName;
        this._vector = jsonThreat.lang_description.vector;
        this._localizedResolution = jsonThreat.lang_description.deviceResolution;
        this._localizedAlertButtonLink = jsonThreat.lang_description.deviceAlertLink ?? "";
        this._localizedAlertButtonText = jsonThreat.lang_description.deviceAlertButton ?? "";
      } else {
        this._internalName = "";
        this._localizedAlertText = "";
        this._localizedAlertTextHtml = "";
        this._localizedDetails = "";
        this._localizedDetailsHtml = "";
        this._localizedName = "";
        this._vector = "";
        this._localizedAlertButtonLink = "";
        this._localizedAlertButtonText = "";
      }
      this._internalThreatID = jsonThreat.legacyThreatId as number;
      this._isMitigated = jsonThreat.mitigated as boolean;
      this._isSimulated = jsonThreat.internalName == "simulated_threat";
      this._json = jsonThreat;

      this._packageName = forensicJson.package ??
        forensicJson.SideloadedAppPackage ??
        forensicJson.AppPackageName ??
        forensicJson.Application ??
        serverOOCDetail.package ??
        serverSuspiciousIPADetail.package ??
        '';

      this._severity = ZThreatSeverity.fromString(jsonThreat.severity);
      this._SSID = forensicJson.ssid ?? "";
      this._url = jsonThreat.SuspectedUrl ?? "";
      this._UUID = jsonThreat.uuid ?? "";
    }
  }

  /**
   * @property appName - the App name of an App threat. An empty string if the Label is not available.
   */
  public get appName() {
    return this._appName;
  }

  /**
   * @property attackTime - the date and time of the threat detection.
   */
  public get attackTime() {
    return this._attackTime;
  }

  /**
  * @property malwareFamily - the family name of the malware threat. An empty string if the Label is not available.
  */
  public get malwareFamily() {
    return this._malwareFamily;
  }

  /**
  *  @property malwareName - the name of the malware threat. An empty string if the Label is not available.
  */
  public get malwareName() {
    return this._malwareName;
  }


  /**
  * @property profileName - the name of the suspicious profile threat. An empty string if the Label is not available.
  */
  public get profileName() {
    return this._profileName;
  }


  /**
  * @property sideloadedAppDeveloper - the app developer for a sideloaded app threat. An empty string if the Label is not available.
  */
  public get sideloadedAppDeveloper() {
    return this._sideloadedAppDeveloper;
  }

  /**
   * @property internalName - the internal threat name.
   */
  public get internalName() {
    return this._internalName;
  }

  /**
   * @property internalThreatID - the internal threat ID.
   */
  public get internalThreatID() {
    return this._internalThreatID;
  }

  /**
   * @property isMitigated - true if the threat has been mitigated.
   */
  public get isMitigated() {
    return this._isMitigated;
  }

  /**
   * @property isSimulated - true if this threat is a simulated test threat.
   */
  public get isSimulated() {
    return this._isSimulated;
  }

  /**
   * @property json - the threat key/value pair set describing this threat.
   */
  public get json() {
    return this._json;
  }

  /**
   * @property localizedAlertText - the user configured alert string with HTML elements removed. The alert string can be configured in zConsole.
   */
  public get localizedAlertText() {
    return this._localizedAlertText;
  }

  /**
   * @property localizedAlertTextHtml - the user configured alert string including HTML elements. The alert string can be configured in zConsole.
   */
  public get localizedAlertTextHtml() {
    return this._localizedAlertTextHtml;
  }

  /**
   * @property localizedDetails - the localized (configurable) description of the attack with HTML elements removed.
   */
  public get localizedDetails() {
    return this._localizedDetails;
  }

  /**
   * @property localizedDetailsHtml - the localized (configurable) description of the attack including HTML elements.
   */
  public get localizedDetailsHtml() {
    return this._localizedDetailsHtml;
  }

  /**
   * @property localizedName - the localized name of the threat reported (example, "ARP MITM", "SSL STRIP", "TCP SCAN", etc).
   */
  public get localizedName() {
    return this._localizedName;
  }

  /**
   * @property localizedResolution - Retrieves the localized threat resolution message without HTML tags.
   */
  public get localizedResolution() {
    return this._replaceHtml(this._localizedResolution);
  }

  /**
   * @property localizedResolutionHtml - Retrieves the localized threat resolution message in HTML format.
   */
  public get localizedResolutionHtml() {
    return this._localizedResolution;
  }

  /**
   * @property localizedAlertButtonLink- the user configured alert button link. The alert button link can be configured in zConsole.
   */
  public get localizedAlertButtonLink() {
    return this._localizedAlertButtonLink;
  }

  /**
   * @property localizedAlertButtonText - the user configured alert button string. The alert button string can be configured in zConsole.
   */
  public get localizedAlertButtonText() {
    return this._localizedAlertButtonText;
  }

  /**
   * @property packageName - the App name of an App threat. An empty string if the Label is not available.
   */
  public get packageName() {
    return this._packageName;
  }

  /**
   * @property severity - the severity of the threat reported ("THREATSEVERITY_CRITICAL", "ITHREATSEVERITY_MPORTANT", "THREATSEVERITY_LOW").
   */
  public get severity() {
    return this._severity;
  }

  /**
   * @property SSID - the SSID of the access point when the attack was detected. Only present when the device was connected to a wifi network.
   * An empty string if the Label is not available.
   */
  public get SSID() {
    return this._SSID;
  }

  /**
   * @property url - the URL of a web threat or an empty string for other threats.
   */
  public get url() {
    return this._url;
  }

  /**
   * @property UUID - the unique threat UUID value. Each generated threat will have a unique UUID that can be used to identify the specific threat.
   */
  public get UUID() {
    return this._UUID;
  }

  /**
   * @property vector - the threat vector description.
   *
   * @return the threat vector description string of the following possible values (new entries may be added dynamically):
   *   "DEVICE" - for device related threats
   *   "NETWORK" - for network related threats
   *   "APP" - for application related threats
   *   "WEB" - for URL scan and content inspection related threats
   *   "TRACKER" - for tracker related threats (e.g. AirTag)
   */
  public get vector() {
    return this._vector;
  }

  /**
   * Get the threat debug description.
   *
   * @return the threat description string.
   */
  public toString() {
    return `ZDefendThreat {
      appName: ${this._appName},
      attackTime: ${this._attackTime.toISOString()},
      internalName: ${this._internalName},
      internalThreatID: ${this._internalThreatID},
      isMitigated: ${this._isMitigated},
      isSimulated: ${this._isSimulated},
      json: ${JSON.stringify(this._json)},
      localizedAlertText: ${this._localizedAlertText},
      localizedAlertTextHtml: ${this._localizedAlertTextHtml},
      localizedDetails: ${this._localizedDetails},
      localizedDetailsHtml: ${this._localizedDetailsHtml},
      localizedName: ${this._localizedName},
      localizedResolution: ${this._localizedResolution},
      packageName: ${this._packageName},
      severity: ${ZThreatSeverity[this._severity]},
      SSID: ${this._SSID},
      url: ${this._url},
      UUID: ${this._UUID},
      vector: ${this._vector}}
    }`;
  }

  private _replaceHtml(htmlAlertText: string): string {
    let text: string = htmlAlertText;
    text = text.replace(/<br>/g, "\n").replace(/<[^>]*>/g, "");
    return text;
  }

}
