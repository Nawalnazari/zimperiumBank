
import type { ZDeviceStatusJsonCallback } from "./ZDefend";
import { ZDefendImpl } from "./zdefend/ZDefendImpl";

/// The device status handler registration object returned from ZDefend#addDeviceStatusJsonCallback:ZDeviceStatusJsonCallback.
///
/// This object can be used to de-register the handler when device status json updates are no longer required.
///
export class ZDeviceStatusJsonRegistration {
    /// [callback] -  the callback implementation block tracked by this registration. nil is returned after calling ZDeviceStatusJsonRegistration#deregister.
    public callback: ZDeviceStatusJsonCallback;
    public nonceString: String | undefined;

    constructor(callback: ZDeviceStatusJsonCallback, nonceString: String | undefined) {
        this.callback = callback;
        this.nonceString = nonceString;
    }

    /// Remove the device status handler from receiving device status change events.
    deregister(): void {
        ZDefendImpl.getInstance().removeDeviceStatusJsonCallback(this);
    }
}
