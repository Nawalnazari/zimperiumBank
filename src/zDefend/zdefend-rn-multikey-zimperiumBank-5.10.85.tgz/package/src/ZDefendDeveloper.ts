import { ZDefendRuleLevel } from "./enums/ZDefendRuleLevel";
import { ZEvents } from "./zimperium_rn_events";


/**
 * ZDefendDeveloper is the developer assist api to aid in development and debugging.
 *
 */
export class ZDefendDeveloper {

  /**
   * Simulate a threat for testing. Refer to ZDefend documentation for details.
   * @param threatId the threat identifier to simulate.
   * @param forensics the threat forensic details.
   */
  static simulateTestThreat({ threatId, forensics }: { threatId: number, forensics: object }): void {
    try {
      let details: object = {
        "legacyThreatId": threatId,
        "forensicJson": JSON.stringify(forensics)
      };
      ZEvents.submit("com.zimperium.api.internal.simulate_threat", JSON.stringify(details));
    } catch(e){
      console.log(e);
    }
  }

  /**
   * Remove all active simulated test threats.
   */
  static mitigateSimulatedThreats(): void {
    ZEvents.submit("com.zimperium.api.internal.remove_simulated_threats");
  }

  /**
   * Set the rule run level to production or beta rules. This developer API allows testing using beta
   * run rules. Setting the rule level is persistent across application restarts.
   *
   * @param level the rule level to in effect.
   */
  static setRuleLevel({ level }: { level: ZDefendRuleLevel }): void {
    let levelString: string = level == ZDefendRuleLevel.BETA ? "beta" : "production";
    let ruleLevelData : object = {
      "com.zimperium.zdd.rule_level": levelString,
      "_db": "advcfg"
    }
    ZEvents.submitForResponse("com.zimperium.zdefendx.stat.update", JSON.stringify(ruleLevelData), (value: string) => {
      console.log("Rule Level set, result: " + value);
    });
  }
}
