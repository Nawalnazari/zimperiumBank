import { ZDefendUrlClassificationResult } from './ZDefendUrlClassificationResult';
import { ZEvents } from "../zimperium_rn_events";

/**
 * ZDefendUrlClassificationResultCallback is the handler block for receiving the results from a URL classification request, see ZDefendUrlClassification#classifyUrl.
 *
 * A class implementing this interface is required for receiving the URL classification results.
 *
 * @param classifyUrlResult The URL classification results.
 * @param error Any error exceptions that occurred processing the URL classification. nil is returned for no errors.
 */
type ClassificationResultCallback = (classifyUrlResult: ZDefendUrlClassificationResult, error: string) => void;

/**
 * The ZDefend URL Classification API.
 */
export class ZDefendUrlClassification {
  /**
   * Request a URL classification for phishing or content-filtering.
   *
   * The URL classification will asynchronously verify the passed URL and provide the scan result to the provided callback.
   *
   * URL classification results determined as phishing or filtered will additionally trigger a web threat.
   *
   * @param url - The url to be classified, e.g. https://zimperium.com
   * @param callback - handler to be called asynchronously to delver the classification result. See ZDefendUrlClassificationResultCallback.
   */

  static classifyUrl({ url, callback }: { url: string, callback: ClassificationResultCallback }): void {
    console.log("classifyUrl(" + url + ")");

    if (!(url.toLocaleLowerCase().startsWith("http://") || url.toLocaleLowerCase().startsWith("https://"))) {
      console.log("invalid scheme for url: " + url);
      return;
    }
    let urlDetail = {
      "url": url
    }
    ZEvents.submitForResponse("com.zimperium.api.internal.scan_url",
      JSON.stringify(urlDetail),
      (value: string) => {
        const classifyResult = JSON.parse(value);
        var error: string = "";
        var threat: string = "{}";
        if (classifyResult.hasOwnProperty("error")) {
          error = classifyResult.getString("error");
        } else if (classifyResult.hasOwnProperty("status") && (classifyResult["status"] === "no_listeners")) {
          error = "no_listeners"; // internal code bug
        } else if (classifyResult.hasOwnProperty("threat")) {
          threat = classifyResult["threat"];
        }
        callback(new ZDefendUrlClassificationResult(url, threat), error);
      }
    );
  }


  /**
   * Mitigate all active web threats.
   *
   * Mitigation is an asynchronous action. Any mitigated web threats will generate a ZDeviceStatusCallback with the updated web threat.
   */
  static mitigateWebThreats(): void {
    let urlDetail = {
      "url": "*"
    }
    ZEvents.submit("com.zimperium.threat.mitigate_by_url_internal", JSON.stringify(urlDetail));
  }
}
