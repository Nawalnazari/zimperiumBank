import { ZContentInspectionMode } from '../enums/ZContentInspectionMode';
import { ZDefendThreat } from '../zdefend_threat/ZDefendThreat';
import { ZEvents } from "../zimperium_rn_events";

/**
 * The result from the ZDefendUrlClassification. See {@link ZDefendUrlClassification#classifyUrl(String, ZDefendUrlClassificationCallback)}.
 */
export class ZDefendUrlClassificationResult {
  private _url: string;
  private _threat: ZDefendThreat = new ZDefendThreat({});
  private _isPhishing: boolean = false;
  private _contentCategory: string = "";
  private _isSafe: boolean = true;
  private _debugDescription: string | undefined;

  constructor(url: string, threatJSON: string) {
    this._url = url;
    if(threatJSON != "{}") {
      const parsedThreatJson = JSON.parse(JSON.stringify(threatJSON));
      this._threat = new ZDefendThreat(parsedThreatJson);
      const forensicJson = JSON.parse(JSON.parse(JSON.stringify(this._threat.json))['forensicJson'])

      let ruleName = forensicJson['_rule_name'] as string;
      this._isPhishing = ruleName.includes('zphish_') ?? false;
      this._isSafe = false;
      this._contentCategory = forensicJson['localized_category_name'] ?? "";
    }
    this._debugDescription = this._toString();
  }

  private _toString(): string {
    return `ZDefendUrlClassificationResult {
      url: ${this._url},
      threat: ${this._threat.toString()},
      isPhishing: ${this._isPhishing},
      contentCategory: ${this._contentCategory},
      isSafe: ${this._isSafe}
    }`;
  }

  /**
   * @property url - the url requsted for this result.
   */
  public get url() {
    return this._url;
  }

  /**
   * @property threat - the result threat details. All unsafe results will include classification threat details. See ZDefendThreat.
   *
   * nil when the ZDefendUrlClassificationResult#isSafe is false, the threat details object when ZDefendUrlClassificationResult#isSafe is true.
   */
  public get threat() {
    return this._threat;
  }

  /**
   * contentInspectionMode - the content inspection mode for this status.
   */
  public async getContentInspectionMode(): Promise<ZContentInspectionMode> {
    try {
      let details = {
        'stat_id': "com.zimperium.zdetection.content_filter.enabled"
      }
      const isContentFilterEnabled = await new Promise<boolean>((resolve) => {
        ZEvents.submitForResponse("com.zimperium.zdefendx.stat.retrieve", JSON.stringify(details), (result: string) => {
          let response = JSON.parse(result)["stat_value"] as boolean
          resolve(response);
        });
      });
      if(isContentFilterEnabled) {
        return ZContentInspectionMode.CONTENT_FILTERING;
      } else {
        return ZContentInspectionMode.PHISHING;
      }
    } catch (error) {
      console.error("Error occurred:", error);
      return ZContentInspectionMode.DISABLED;
    }
  }

  /**
   * @property isPhishing - if this ZDefend URL Classification result is classified as phishing.
   *
   * true only if the classification result is a phishing classification,
   *  or false when the result is safe or {@link #getContentInspectionMode()} is not PHISHING.
   */
  public get isPhishing() {
    return this._isPhishing;
  }

  /**
   * The content filtering category of the ZDefend URL classification result or empty string if the result is safe or {@link #getContentInspectionMode()} is not CONTENT_FILTERING.
   */

  public get contentCategory() {
    return this._contentCategory;
  }

  /**
   * @property isSafe - the result safety. Any unsafe result will have threat details available, see ZDefendUrlClassificationResult#getThreat.
   *      true for result that is determined safe
   *      false for a result that was identified as phishing or content filtered.
   */
  public get isSafe() {
    return this._isSafe;
  }

  /**
   * Get the result debug description.
   *
   * @return the result debug description string.
   */
  public get debugDescription() {
    return  this._debugDescription;
  }
}
