import { ZDefendPolicyType } from '../enums/ZDefendPolicyType';

/**
 * A ZDefend policy description.
 */

export class ZDefendPolicy {

  private _policyType: ZDefendPolicyType;
  private _policyDownloadDate: Date;
  private _policyHash: string;

  constructor(type: ZDefendPolicyType, date: Date, hash: string) {
    this._policyType = type;
    this._policyDownloadDate = date;
    this._policyHash = hash;
  }

  /**
   * @property policyType - the current policy type.
   */
  public get policyType() {
    return this._policyType;
  }

  /**
   * @property policyDownloadDate - the policy download date and time.
   */
  public get policyDownloadDate() {
    return this._policyDownloadDate;
  }

  /**
   * @property policyHash - the policy hash value that uniquely identifies the policy.
   */
  public get policyHash() {
    return this._policyHash;
  }

  /**
 * Generates a string representation of the ZDefendPolicy object.
 */
  public toString(): string {
    return `ZDefendPolicy {
        policyType: ${this._policyType},
        policyDownloadDate: ${this._policyDownloadDate},
        policyHash: ${this._policyHash}
      }`;
  }

}
