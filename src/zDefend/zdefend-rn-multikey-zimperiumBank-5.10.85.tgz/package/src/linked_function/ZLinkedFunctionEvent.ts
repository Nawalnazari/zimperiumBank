import type { ZDefendThreat } from "../zdefend_threat/ZDefendThreat";
import type { ZDeviceStatus } from "../ZDeviceStatus";
import type { ZLinkedFunctionEventType } from "../enums/ZLinkedFunctionEventType";

/**
 * ZLinkedFunctionEvent is class representing the a triggered linked function event. These events are passed to registered
 * linked function callbacks when a linked function event is triggered.
 * See ZDefend.registerLinkedFunction for registering linked functions.
 */
export class ZLinkedFunctionEvent {
    private _label: string;
    private _eventType: ZLinkedFunctionEventType;
    private _deviceStatus: ZDeviceStatus;
    private _relatedThreats: ZDefendThreat[];

    constructor(label: string, eventType: ZLinkedFunctionEventType, status: ZDeviceStatus, threats: ZDefendThreat[]) {
        this._label = label;
        this._eventType = eventType;
        this._deviceStatus = status;
        this._relatedThreats = threats;
    }

    /**
     * Get the label for this ZLinkedFunction event.
     * @returns The event label.
     */
    public get label(): string {
        return this._label;
    }

    /**
     * Get the EventType for this ZLinkedFunction event.
     * @returns The event type.
     */
    public get eventType(): ZLinkedFunctionEventType {
        return this._eventType;
    }

    /**
     * Get the ZDeviceStatus for when this ZLinkedFunction event was generated.
     * @returns The device status for this event.
     */
    public get deviceStatus(): ZDeviceStatus {
        return this._deviceStatus;
    }

    /**
     * Get the list of related threats for this ZLinkedFunction event.
     * @returns The list of related threats.
     */
    public get relatedThreats(): ZDefendThreat[] {
        return this._relatedThreats;
    }

    /**
     * Returns a string representation of the LinkedFunctionEvent object.
     * @returns The string representation.
     */
    public toString(): string {
        return `LinkedFunctionEvent {
            label: ${this._label},
            eventType: ${this._eventType},
            deviceStatus: ${this._deviceStatus.toString()},
            relatedThreats: [${this._relatedThreats.map((threat) => threat.toString()).join(', ')}],
        }`;
    }
}
