import type { ZLinkedFunctionEvent } from "./ZLinkedFunctionEvent";

/**
 * ZLinkedFunction is the interface for receiving linked function events.
 * 
 * A class implementing this interface is required for receiving linked function events.
 * See ZDefend.registerLinkedFunction(String, ZLinkedFunction, ZLinkedFunction) for registering linked functions.
 * 
 */
export type ZLinkedFunction = (event: ZLinkedFunctionEvent) => void;


export class ZLinkedFunctionRegistration {
    private _regId: number | undefined; 
    private _label: string;
    private _linkedFunction: ZLinkedFunction;
    private _mitigateLinkedFunction: ZLinkedFunction;
    private _deregistered = false;

    constructor(regId: number | undefined, label: string, linkedFunction: ZLinkedFunction, mitigateLinkedFunction: ZLinkedFunction) {
        this._label = label;
        this._linkedFunction = linkedFunction;
        this._mitigateLinkedFunction = mitigateLinkedFunction;
        this._regId = regId;
    }

    public get label() {
        return this._label;
    }

    public get linkedFunction() {
        return this._linkedFunction;
    }

    public get mitigateLinkedFunction() {
        return this._mitigateLinkedFunction;
    }

    public remove(): void {
        this._deregistered = true;
    }

    public get deregistered() {
        return this._deregistered;
    }

    public get regId(): number | undefined {
        return this._regId;
    }

    public set regId(id: number | undefined) {
        this._regId = id;
    }
}
