import { ZDefendImpl } from './zdefend/ZDefendImpl';
import { ZDefendPolicyType } from './enums/ZDefendPolicyType';
import { ZLoginError } from './enums/ZLoginError';
import { ZLoginStatus } from './enums/ZLoginStatus';
import { ZDefendPolicy } from './zdefend_policy/ZDefendPolicy';
import { ZDefendThreat } from './zdefend_threat/ZDefendThreat';
import { ZDeviceStatusCompressionType } from './enums/ZDeviceStatusCompressionType';
var Buffer = require('buffer/').Buffer

const _POLICY_NAMES_MAP: { [key: string]: ZDefendPolicyType } = {
  'App Settings': ZDefendPolicyType.APP_SETTINGS,
  'Phishing': ZDefendPolicyType.PHISHING,
  'Privacy': ZDefendPolicyType.PRIVACY,
  'Threat': ZDefendPolicyType.THREAT,
  'Knox': ZDefendPolicyType.KNOX,
};

/**
 * The device status describing the ZDefend state when the status event occurred. See ZDeviceStatusCallback.
 *
 * The device status is updated when new policies are processed, device threats are generated and mitigated, and the device login status changes.
 *
 * The device status provides the base64 encoded status and the digital signature that can be used to verify the event authenticity.
 */
export class ZDeviceStatus {
  private _statusDate = new Date();;
  private _deviceStatusBase64: string = "";
  private _deviceStatusBase64Signature: string = "";
  private _loginStatus: ZLoginStatus = ZLoginStatus.LOGGED_OUT;
  private _loginLastError: ZLoginError = ZLoginError.NONE;
  private _initialScanProgressPercentage: number = 0;
  private _sdkVersion: string = "";
  private _deviceId: string = "";

  private _devicePolicies: ZDefendPolicy[] = [];
  private _allThreats: ZDefendThreat[] = [];
  private _activeThreats: ZDefendThreat[] = [];
  private _mitigatedThreats: ZDefendThreat[] = [];
  private _activeNewThreats: ZDefendThreat[] = [];
  private _mitigatedNewThreats: ZDefendThreat[] = [];

  private _decodedStatus: string = "";

  private _threatTextExcluded: boolean = false;
  private _policyStatusExcluded: boolean = false;
  private _compressedDeviceStatusBase64: String | undefined;
  private _compressedDeviceStatusBase64Signature: String | undefined;
  private _compressionType: ZDeviceStatusCompressionType = ZDeviceStatusCompressionType.COMPRESSION_TYPE_NONE;

  constructor(encodedStatus: string, priorStatus?: ZDeviceStatus) {
    try {
      var rawJson = JSON.parse(encodedStatus);
      var base64Status = rawJson.device_status_base64 ?? rawJson.device_status?.device_status_base64;

      this._compressedDeviceStatusBase64 = rawJson.compressed_device_status_base64;
      this._compressedDeviceStatusBase64Signature = rawJson.compressed_signature;

      var deviceStatusConfig = rawJson.config ?? {};
      if (deviceStatusConfig) {
        this._threatTextExcluded = deviceStatusConfig.exclude_text ?? false;
        this._policyStatusExcluded = deviceStatusConfig.exclude_policies ?? false;

        const compression = deviceStatusConfig.compression ?? '';
        if (compression && compression === "deflate") {
          this._compressionType = ZDeviceStatusCompressionType.COMPRESSION_TYPE_DEFLATE;
        }
      }

      if (base64Status) {
        this._decodedStatus = Buffer.from(base64Status, 'base64').toString('utf-8');
        const statusJson = JSON.parse(this._decodedStatus);
        this._statusDate = new Date(statusJson.date);
        this._deviceStatusBase64 = base64Status;
        this._deviceStatusBase64Signature = rawJson.signature;
        this._loginStatus = ZLoginStatus.fromString(statusJson.status);
        this._loginLastError = this._generateLastLoginError(this._loginStatus, statusJson.login_last_error);
        this._initialScanProgressPercentage = statusJson.scan_progress_percentage;
        this._generateDevicePolicies(statusJson.policies);
        this._generateThreats(statusJson.threats, priorStatus);
        this._deviceId = statusJson.device_id;
        this._sdkVersion = statusJson.sdk_version;
      }
    } catch (e) {
      this._statusDate = new Date();
      this._deviceStatusBase64 = "";
      this._deviceStatusBase64Signature = "";
      this._loginStatus = ZLoginStatus.LOGGED_OUT;
      this._loginLastError = ZLoginError.NONE;
      this._initialScanProgressPercentage = 0;
      console.log("Error ", e);
    }
  }

  /**
   * @property deviceId -  unique device.
  */
  public get deviceId() {
    return this._deviceId;
  }


  /**
   * @property sdkVersion -  current ZDefend sdk version.
   */
  public get sdkVersion() {
    return this._sdkVersion;
  }

  /**
   * @property statusDate -  the device status generation time/date.
   */
  public get statusDate() {
    return this._statusDate;
  }

  /**
   * @property deviceStatusBase64 - the base64 encoded device status. This is the base64 encoding of the json key/value pairs
   * describing this device status. The base64 string can be authenticated using the digital signature, see ZDeviceStatus#getBase64Signature.
   */
  public get deviceStatusBase64() {
    return this._deviceStatusBase64;
  }

  /**
   * @property deviceStatusBase64Signature - the base64 device status digital signature. See ZDeviceStatus#getBase64.
   */
  public get deviceStatusBase64Signature() {
    return this._deviceStatusBase64Signature;
  }

  /**
   * @property loginStatus - the login status.
   */
  public get loginStatus() {
    return this._loginStatus;
  }

  /**
   * @property initialScanProgressPercentage - Get the initial scan progress percentage. 0 as the scan is starting,
   * 1 to 99 of the current scan progress percentage, 100 when the scan is complete. The initial scan starts immediately after ZDefend login.
   * .
   */
  public get initialScanProgressPercentage() {
    return this._initialScanProgressPercentage;
  }

  /**
   * @property devicePolicies - a list of ZDefendPolicy objects.
   */
  public get devicePolicies() {
    return this._devicePolicies;
  }

  /**
   * @property allThreats - the threats in the device device status. The threat list will include all new, active and previous threats including mitigated threats.
   */
  public get allThreats() {
    return this._allThreats;
  }

  /**
   * @property activeThreats - the  non-mitigated only threat list of the ZDeviceStatus event.
   */
  public get activeThreats() {
    return this._activeThreats;
  }

  /**
   * @property mitigatedThreats - the mitigated only threat list of the ZDeviceStatus event.
   */
  public get mitigatedThreats() {
    return this._mitigatedThreats;
  }

  /**
   * @property activeNewThreats - the new non-mitigated threat list since the prior ZDeviceStatus event.
   */
  public get activeNewThreats() {
    return this._activeNewThreats;
  }

  /**
   * @property mitigatedNewThreats - the new mitigated threat list since the prior ZDeviceStatus event.
   */
  public get mitigatedNewThreats() {
    return this._mitigatedNewThreats;
  }

  /**
   * @property loginLastError - the last login error. See ZLoginError.
   *          LOGIN_ERROR_LOGGED_IN is returned when loginStatus is LOGGED_IN.
   */
  public get loginLastError() {
    return this._loginLastError;
  }

  /**
  * @property threatTextExcluded - Get the text excluded configuration state for this device status event. See ZDeviceStatus#excludeThreatText(boolean).
  * Property is  true if the localized text has been excluded for this event.
  */
  public get threatTextExcluded() {
    return this._threatTextExcluded;
  }


  /**
   * @property policyStatusExcluded - Get the policy status excluded configuration state for this device status event. See ZDeviceStatus#excludePolicyStatus(boolean).
   * Property is true if the policy status has been excluded for this event.
   */
  public get policyStatusExcluded() {
    return this._policyStatusExcluded;
  }

  /**
   * @property compressedDeviceStatusBase64 - the compressed base64 encoded device status. This is the base64 encoding of the json key/value pairs
   * describing this device status. The base64 string can be authenticated using the digital signature, see ZDeviceStatus#getBase64Signature.
   * See #getCompressionType() for how this data is compressed.
   * This property is nil if compression is set to COMPRESSION_TYPE_NONE. See #setCompressionType(CompressionType).
   * Value is nil if
   */
  public get compressedDeviceStatusBase64() {
    return this._compressedDeviceStatusBase64;
  }

  /**
  * @property compressedDeviceStatusBase64Signature - the compressed base64 device status digital signature. See ZDeviceStatus#compressedDeviceStatusBase64.
  * This property is nil if compression is set to COMPRESSION_TYPE_NONE. See #setCompressionType(CompressionType).
  */
  public get compressedDeviceStatusBase64Signature() {
    return this._compressedDeviceStatusBase64Signature;
  }

  /**
   * Get the compression type used for this device status event. See ZDeviceStatus#setCompressionType(ZDeviceStatusCompressionType).
   * @return the data compression type used for #getCompressedBase64()}. COMPRESSION_TYPE_NONE is returned if compressed is not enabled.
   */
  public get compressionType() {
    return this._compressionType;
  }




  private _generateLastLoginError(loginStatus: ZLoginStatus, loginLastError: string): ZLoginError {
    if (loginStatus != ZLoginStatus.LOGGED_OUT) {
      return ZLoginError.NONE;
    } else {
      if (!loginLastError) {
        return ZLoginError.NONE;
      }
      return ZLoginError.fromString(loginLastError);
    }
  }

  private _generateDevicePolicies(policiesJson: any): void {
    if (policiesJson) {
      for (const key in _POLICY_NAMES_MAP) {
        var type = _POLICY_NAMES_MAP[key] ?? ZDefendPolicyType.THREAT;
        var dateValue = policiesJson[`${key} Policy Date`];
        var date = new Date(dateValue);
        var hash = policiesJson[`${key} Policy Hash`];
        this._devicePolicies.push(new ZDefendPolicy(type, date, hash))
      }
    }
  }

  private _generateThreats(jsonThreats: any, priorStatus?: ZDeviceStatus): void {
    const priorThreats = new Map<string, ZDefendThreat>();
    if (priorStatus) {
      for (const threat of priorStatus.allThreats) {
        priorThreats.set(threat.UUID, threat);
      }
    }

    this._allThreats = [];
    this._mitigatedThreats = [];
    this._activeThreats = [];
    this._mitigatedNewThreats = [];
    this._activeNewThreats = [];

    for (const json of jsonThreats) {
      const threat = new ZDefendThreat(json);
      this._allThreats.push(threat);

      if (threat.isMitigated) {
        this._mitigatedThreats.push(threat);
      } else {
        this._activeThreats.push(threat);
      }

      if (priorStatus) {
        let oldThreat = priorThreats.get(threat.UUID);

        if (!oldThreat || (oldThreat!.isMitigated != threat.isMitigated)) {
          if (threat.isMitigated) {
            this._mitigatedNewThreats.push(threat);
          } else {
            this._activeNewThreats.push(threat);
          }
        }
      }
    }
  }

  public toString(): string {
    //deviceStatusBase64: ${this._deviceStatusBase64},
    return `ZDeviceStatus {
      deviceId: ${this._deviceId},
      sdkVersion: ${this._sdkVersion},
      statusDate: ${this._statusDate},
      deviceStatusBase64Signature: ${this._deviceStatusBase64Signature},
      loginStatus: ${this._loginStatus},
      loginLastError: ${this._loginLastError},
      initialScanProgressPercentage: ${this._initialScanProgressPercentage},
      threatTextExcluded: ${this._threatTextExcluded},
      policyStatusExcluded: ${this._policyStatusExcluded},
      compressedDeviceStatusBase64: ${this._compressedDeviceStatusBase64},
      compressedDeviceStatusBase64Signature: ${this._compressedDeviceStatusBase64Signature},
      compressionType: ${this._compressionType},
      devicePolicies: [${this._devicePolicies.map((policy) => policy.toString()).join(', ')}],
      allThreats: [${this._allThreats.map((threat) => threat.toString()).join(', ')}],
      activeThreats: [${this._activeThreats.map((threat) => threat.toString()).join(', ')}],
      mitigatedThreats: [${this._mitigatedThreats.map((threat) => threat.toString()).join(', ')}],
      activeNewThreats: [${this._activeNewThreats.map((threat) => threat.toString()).join(', ')}],
      mitigatedNewThreats: [${this._mitigatedNewThreats.map((threat) => threat.toString()).join(', ')}]
    }`;
  }


  /**
   * Configure the device status to exclude localized text from device status updates. Setting true will reduce the device status event size.
   * This configuration is persistent for the current login.
   * @param excludeText true to exclude localized text from status updates. The default configuration is false.
   */
  public static setExcludeThreatText(excludeText: boolean): void {
    ZDefendImpl.getInstance().setExcludeThreatText(excludeText);
  }

  /**
   * Configure the device status to exclude policy status from device status updates. Setting true will reduce the device status event size.
   * This configuration is persistent for the current login.
   * @param excludePolicyStatus true to exclude policy status from status updates. The default configuration is false.
   */
  public static setExcludePolicyStatus(excludePolicyStatus: boolean): void {
    ZDefendImpl.getInstance().setExcludePolicyStatus(excludePolicyStatus);
  }

  /**
   * Configure the device status to produce compressed base64 device status. ZDeviceStatus#getCompressedBase64().
   * By default compression is disabled and the type is set to COMPRESSION_TYPE_NONE.
   * @param type the compression type use.
   */
  public static setCompressionType(type: ZDeviceStatusCompressionType): void {
    ZDefendImpl.getInstance().setCompressionType(type);
  }
}