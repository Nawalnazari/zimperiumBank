import { ZDefendUrlClassificationResult } from './ZDefendUrlClassificationResult';
/**
 * ZDefendUrlClassificationResultCallback is the handler block for receiving the results from a URL classification request, see ZDefendUrlClassification#classifyUrl.
 *
 * A class implementing this interface is required for receiving the URL classification results.
 *
 * @param classifyUrlResult The URL classification results.
 * @param error Any error exceptions that occurred processing the URL classification. nil is returned for no errors.
 */
type ClassificationResultCallback = (classifyUrlResult: ZDefendUrlClassificationResult, error: string) => void;
/**
 * The ZDefend URL Classification API.
 */
export declare class ZDefendUrlClassification {
    /**
     * Request a URL classification for phishing or content-filtering.
     *
     * The URL classification will asynchronously verify the passed URL and provide the scan result to the provided callback.
     *
     * URL classification results determined as phishing or filtered will additionally trigger a web threat.
     *
     * @param url - The url to be classified, e.g. https://zimperium.com
     * @param callback - handler to be called asynchronously to delver the classification result. See ZDefendUrlClassificationResultCallback.
     */
    static classifyUrl({ url, callback }: {
        url: string;
        callback: ClassificationResultCallback;
    }): void;
    /**
     * Mitigate all active web threats.
     *
     * Mitigation is an asynchronous action. Any mitigated web threats will generate a ZDeviceStatusCallback with the updated web threat.
     */
    static mitigateWebThreats(): void;
}
export {};
//# sourceMappingURL=ZDefendUrlClassification.d.ts.map