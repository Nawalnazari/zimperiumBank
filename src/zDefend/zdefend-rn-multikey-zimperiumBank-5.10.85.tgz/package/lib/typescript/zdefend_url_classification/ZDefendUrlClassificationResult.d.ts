import { ZContentInspectionMode } from '../enums/ZContentInspectionMode';
import { ZDefendThreat } from '../zdefend_threat/ZDefendThreat';
/**
 * The result from the ZDefendUrlClassification. See {@link ZDefendUrlClassification#classifyUrl(String, ZDefendUrlClassificationCallback)}.
 */
export declare class ZDefendUrlClassificationResult {
    private _url;
    private _threat;
    private _isPhishing;
    private _contentCategory;
    private _isSafe;
    private _debugDescription;
    constructor(url: string, threatJSON: string);
    private _toString;
    /**
     * @property url - the url requsted for this result.
     */
    get url(): string;
    /**
     * @property threat - the result threat details. All unsafe results will include classification threat details. See ZDefendThreat.
     *
     * nil when the ZDefendUrlClassificationResult#isSafe is false, the threat details object when ZDefendUrlClassificationResult#isSafe is true.
     */
    get threat(): ZDefendThreat;
    /**
     * contentInspectionMode - the content inspection mode for this status.
     */
    getContentInspectionMode(): Promise<ZContentInspectionMode>;
    /**
     * @property isPhishing - if this ZDefend URL Classification result is classified as phishing.
     *
     * true only if the classification result is a phishing classification,
     *  or false when the result is safe or {@link #getContentInspectionMode()} is not PHISHING.
     */
    get isPhishing(): boolean;
    /**
     * The content filtering category of the ZDefend URL classification result or empty string if the result is safe or {@link #getContentInspectionMode()} is not CONTENT_FILTERING.
     */
    get contentCategory(): string;
    /**
     * @property isSafe - the result safety. Any unsafe result will have threat details available, see ZDefendUrlClassificationResult#getThreat.
     *      true for result that is determined safe
     *      false for a result that was identified as phishing or content filtered.
     */
    get isSafe(): boolean;
    /**
     * Get the result debug description.
     *
     * @return the result debug description string.
     */
    get debugDescription(): string | undefined;
}
//# sourceMappingURL=ZDefendUrlClassificationResult.d.ts.map