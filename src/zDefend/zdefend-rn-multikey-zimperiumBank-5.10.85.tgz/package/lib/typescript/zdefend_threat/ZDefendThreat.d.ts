import { ZThreatSeverity } from '../enums/ZThreatSeverity';
/**
 * ZDefendThreat contains all of the information needed to determine what threat was encountered.
 * There are also methods for retrieving the localized threat names and descriptions in human readable format.
 * See ZDeviceStatus.
 */
export declare class ZDefendThreat {
    private _appName;
    private _attackTime;
    private _internalName;
    private _internalThreatID;
    private _isMitigated;
    private _isSimulated;
    private _json;
    private _localizedAlertText;
    private _localizedAlertTextHtml;
    private _localizedDetails;
    private _localizedDetailsHtml;
    private _localizedName;
    private _localizedResolution;
    private _packageName;
    private _severity;
    private _SSID;
    private _url;
    private _UUID;
    private _vector;
    private _malwareFamily;
    private _malwareName;
    private _profileName;
    private _sideloadedAppDeveloper;
    private _localizedAlertButtonLink;
    private _localizedAlertButtonText;
    constructor(jsonThreat: any);
    /**
     * @property appName - the App name of an App threat. An empty string if the Label is not available.
     */
    get appName(): string;
    /**
     * @property attackTime - the date and time of the threat detection.
     */
    get attackTime(): Date;
    /**
    * @property malwareFamily - the family name of the malware threat. An empty string if the Label is not available.
    */
    get malwareFamily(): string;
    /**
    *  @property malwareName - the name of the malware threat. An empty string if the Label is not available.
    */
    get malwareName(): string;
    /**
    * @property profileName - the name of the suspicious profile threat. An empty string if the Label is not available.
    */
    get profileName(): string;
    /**
    * @property sideloadedAppDeveloper - the app developer for a sideloaded app threat. An empty string if the Label is not available.
    */
    get sideloadedAppDeveloper(): string;
    /**
     * @property internalName - the internal threat name.
     */
    get internalName(): string;
    /**
     * @property internalThreatID - the internal threat ID.
     */
    get internalThreatID(): number;
    /**
     * @property isMitigated - true if the threat has been mitigated.
     */
    get isMitigated(): boolean;
    /**
     * @property isSimulated - true if this threat is a simulated test threat.
     */
    get isSimulated(): boolean;
    /**
     * @property json - the threat key/value pair set describing this threat.
     */
    get json(): object;
    /**
     * @property localizedAlertText - the user configured alert string with HTML elements removed. The alert string can be configured in zConsole.
     */
    get localizedAlertText(): string;
    /**
     * @property localizedAlertTextHtml - the user configured alert string including HTML elements. The alert string can be configured in zConsole.
     */
    get localizedAlertTextHtml(): string;
    /**
     * @property localizedDetails - the localized (configurable) description of the attack with HTML elements removed.
     */
    get localizedDetails(): string;
    /**
     * @property localizedDetailsHtml - the localized (configurable) description of the attack including HTML elements.
     */
    get localizedDetailsHtml(): string;
    /**
     * @property localizedName - the localized name of the threat reported (example, "ARP MITM", "SSL STRIP", "TCP SCAN", etc).
     */
    get localizedName(): string;
    /**
     * @property localizedResolution - Retrieves the localized threat resolution message without HTML tags.
     */
    get localizedResolution(): string;
    /**
     * @property localizedResolutionHtml - Retrieves the localized threat resolution message in HTML format.
     */
    get localizedResolutionHtml(): string;
    /**
     * @property localizedAlertButtonLink- the user configured alert button link. The alert button link can be configured in zConsole.
     */
    get localizedAlertButtonLink(): string;
    /**
     * @property localizedAlertButtonText - the user configured alert button string. The alert button string can be configured in zConsole.
     */
    get localizedAlertButtonText(): string;
    /**
     * @property packageName - the App name of an App threat. An empty string if the Label is not available.
     */
    get packageName(): string;
    /**
     * @property severity - the severity of the threat reported ("THREATSEVERITY_CRITICAL", "ITHREATSEVERITY_MPORTANT", "THREATSEVERITY_LOW").
     */
    get severity(): ZThreatSeverity;
    /**
     * @property SSID - the SSID of the access point when the attack was detected. Only present when the device was connected to a wifi network.
     * An empty string if the Label is not available.
     */
    get SSID(): string;
    /**
     * @property url - the URL of a web threat or an empty string for other threats.
     */
    get url(): string;
    /**
     * @property UUID - the unique threat UUID value. Each generated threat will have a unique UUID that can be used to identify the specific threat.
     */
    get UUID(): string;
    /**
     * @property vector - the threat vector description.
     *
     * @return the threat vector description string of the following possible values (new entries may be added dynamically):
     *   "DEVICE" - for device related threats
     *   "NETWORK" - for network related threats
     *   "APP" - for application related threats
     *   "WEB" - for URL scan and content inspection related threats
     *   "TRACKER" - for tracker related threats (e.g. AirTag)
     */
    get vector(): string;
    /**
     * Get the threat debug description.
     *
     * @return the threat description string.
     */
    toString(): string;
    private _replaceHtml;
}
//# sourceMappingURL=ZDefendThreat.d.ts.map