import { ZDefendRuleLevel } from "./enums/ZDefendRuleLevel";
/**
 * ZDefendDeveloper is the developer assist api to aid in development and debugging.
 *
 */
export declare class ZDefendDeveloper {
    /**
     * Simulate a threat for testing. Refer to ZDefend documentation for details.
     * @param threatId the threat identifier to simulate.
     * @param forensics the threat forensic details.
     */
    static simulateTestThreat({ threatId, forensics }: {
        threatId: number;
        forensics: object;
    }): void;
    /**
     * Remove all active simulated test threats.
     */
    static mitigateSimulatedThreats(): void;
    /**
     * Set the rule run level to production or beta rules. This developer API allows testing using beta
     * run rules. Setting the rule level is persistent across application restarts.
     *
     * @param level the rule level to in effect.
     */
    static setRuleLevel({ level }: {
        level: ZDefendRuleLevel;
    }): void;
}
//# sourceMappingURL=ZDefendDeveloper.d.ts.map