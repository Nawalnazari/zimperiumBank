import { NativeEventEmitter } from 'react-native';
import type { EmitterSubscription } from 'react-native';
type result1arg_t = (value: string) => void;
type result2arg_t = (name: string, extra: string) => void;
export declare class ZEvents {
    static eventEmitter: NativeEventEmitter;
    static eventListenListener: EmitterSubscription;
    static eventSubmitForResponseListener: EmitterSubscription;
    static initialized: boolean;
    static gid: number;
    static lmap: {
        [id: string]: result2arg_t;
    };
    static lmap2: {
        [id: string]: string;
    };
    static srmap: {
        [id: string]: result1arg_t;
    };
    static startup(): void;
    static shutdown(): void;
    static listen(name: string, result: result1arg_t, callback: result2arg_t): void;
    static submitForResponse(name: string, details: string, result: result1arg_t): void;
    static submit(name: string, details?: string): void;
    static unlisten(id: string): void;
}
export declare class ZListener {
    private static listenerInstance;
    private constructor();
    static getInstance(): ZListener;
    ids: string[];
    results: {
        [id: string]: result2arg_t;
    };
    start(name: string, _result: result2arg_t): void;
}
export {};
//# sourceMappingURL=zimperium_rn_events.d.ts.map