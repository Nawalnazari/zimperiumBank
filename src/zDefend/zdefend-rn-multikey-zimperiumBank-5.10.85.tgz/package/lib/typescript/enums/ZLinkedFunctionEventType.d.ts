/**
 * The possible event types for a ZLinkedFunctionEvent.
 */
export declare enum ZLinkedFunctionEventType {
    /**
     * The event is a new activated linked function.
     */
    ACTIVATED = 0,
    /**
     * The event is the mitigation of a previous active linked function.
     */
    MITIGATED = 1
}
//# sourceMappingURL=ZLinkedFunctionEventType.d.ts.map