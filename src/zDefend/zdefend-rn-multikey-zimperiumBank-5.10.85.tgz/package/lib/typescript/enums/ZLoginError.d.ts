/**
 *  The possible last login error values returned from ZDeviceStatus#lastLoginError.
 */
export declare enum ZLoginError {
    LOGGED_IN = "LOGGED_IN",
    LICENSE_EXPIRED = "LICENSE_EXPIRED",
    LICENSE_INVALID = "LICENSE_INVALID",
    CONNECTION_ERROR = "CONNECTION_ERROR",
    LICENSE_LIMITED = "LICENSE_LIMITED",
    SERVER_ERROR = "SERVER_ERROR",
    CLIENT_ERROR = "CLIENT_ERROR",
    NONE = "NONE"
}
export declare namespace ZLoginError {
    function fromString(error: string): ZLoginError;
}
//# sourceMappingURL=ZLoginError.d.ts.map