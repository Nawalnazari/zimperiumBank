/**
 * The possible request types for ZDefend#getZLog.
 * Use ZLOG_ALL to request all log messages.
 */
export declare enum ZLogType {
    NORMAL = "NORMAL",
    PHISHING = "PHISHING",
    VPN = "VPN",
    RULE_STATE = "RULE_STATE",
    RULE_DOWNLOAD = "RULE_DOWNLOAD",
    RULE_RUN = "RULE_RUN"
}
export declare namespace ZLogType {
    function fromString(type: string): ZLogType;
}
//# sourceMappingURL=ZLogType.d.ts.map