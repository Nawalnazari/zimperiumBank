/**
 * The possible threat severity values.
 */
export declare enum ZThreatSeverity {
    HIDDEN = "HIDDEN",
    LOW = "LOW",
    IMPORTANT = "IMPORTANT",
    CRITICAL = "CRITICAL"
}
export declare namespace ZThreatSeverity {
    function fromString(level: string): ZThreatSeverity;
}
//# sourceMappingURL=ZThreatSeverity.d.ts.map