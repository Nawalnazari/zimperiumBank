/**
 * Compliance modes for delayed rule activation.
 */
export declare enum DelayedRulesCompliance {
    /**
     * China store compliance mode.
     */
    CHINA_STORE_COMPLIANCE = 0,
    /**
     * Reserved for future policy-based compliance mode.
     */
    POLICY_COMPLIANCE = 1
}
//# sourceMappingURL=DelayedRulesCompliance.d.ts.map