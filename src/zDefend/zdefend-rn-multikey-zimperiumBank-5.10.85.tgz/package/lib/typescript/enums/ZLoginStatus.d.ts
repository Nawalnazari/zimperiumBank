export declare enum ZLoginStatus {
    LOGGED_OUT = "logged_out",
    LOGGED_IN = "logged_in",
    IN_PROGRESS = "authenticating",
    EMBEDDED = "embedded",
    UNKNOWN = "unknown"
}
export declare namespace ZLoginStatus {
    function fromString(status: string): ZLoginStatus;
}
//# sourceMappingURL=ZLoginStatus.d.ts.map