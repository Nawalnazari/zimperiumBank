/**
 * The possible ZDefend policy types.
 */
export declare enum ZDefendPolicyType {
    APP_SETTINGS = "App Settings",
    PHISHING = "Phishing",
    PRIVACY = "Privacy",
    THREAT = "Threat",
    KNOX = "Knox"
}
export declare namespace ZDefendPolicyType {
    function fromString(type: string): ZDefendPolicyType;
}
//# sourceMappingURL=ZDefendPolicyType.d.ts.map