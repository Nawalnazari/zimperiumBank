/**
 * The possible setRuleLevel values, see ZDefendDeveloper#setRuleLevel.
 */
export declare enum ZDefendRuleLevel {
    BETA = "beta",
    PRODUCTION = "production"
}
export declare namespace ZDefendRuleLevel {
    function fromString(level: string): ZDefendRuleLevel;
}
//# sourceMappingURL=ZDefendRuleLevel.d.ts.map