export declare enum ZDefendLicenseKeyNames {
    KEY_0 = "KEY_0",
    KEY_1 = "KEY_1",
    KEY_2 = "KEY_2",
    KEY_3 = "KEY_3",
    KEY_4 = "KEY_4",
    INVALID = "INVALID"
}
export declare namespace ZDefendLicenseKeyNames {
    function fromString(type: string): ZDefendLicenseKeyNames;
}
export declare namespace ZDefendLicenseKeyNames {
    function values(): string[];
    function getIndex(name: ZDefendLicenseKeyNames): number;
}
//# sourceMappingURL=ZDefendLicenseKeyNames.d.ts.map