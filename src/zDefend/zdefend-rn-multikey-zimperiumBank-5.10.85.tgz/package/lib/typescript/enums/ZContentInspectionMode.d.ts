/**
 *  The possible content inspection modes returned from ZDefend#getContentInspectionMode).
 */
export declare enum ZContentInspectionMode {
    PHISHING = "PHISHING",
    CONTENT_FILTERING = "CONTENT_FILTERING",
    DISABLED = "DISABLED"
}
export declare namespace ZContentInspectionMode {
    function fromString(type: string): ZContentInspectionMode;
}
//# sourceMappingURL=ZContentInspectionMode.d.ts.map