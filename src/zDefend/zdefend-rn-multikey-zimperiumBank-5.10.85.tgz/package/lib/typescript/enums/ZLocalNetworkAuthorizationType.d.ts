export declare enum ZLocalNetworkAuthorizationType {
    ZLOCALNETWORK_AUTHORIZATION_NOT_ASKED = 0,
    ZLOCALNETWORK_AUTHORIZATION_DENIED = 1,
    ZLOCALNETWORK_AUTHORIZATION_ALLOWED = 2,
    ZLOCALNETWORK_AUTHORIZATION_ERROR = 3
}
export declare namespace ZLocalNetworkAuthorizationType {
    function fromJson(authorization: string): ZLocalNetworkAuthorizationType;
}
//# sourceMappingURL=ZLocalNetworkAuthorizationType.d.ts.map