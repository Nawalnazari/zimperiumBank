/**
 * Type possible ZDeviceStatus compression type values, see ZDeviceStatus#setCompressionType.
 */
export declare enum ZDeviceStatusCompressionType {
    COMPRESSION_TYPE_NONE = 0,
    COMPRESSION_TYPE_DEFLATE = 1
}
//# sourceMappingURL=ZDeviceStatusCompressionType.d.ts.map