import type { ZDeviceStatusJsonCallback } from "./ZDefend";
export declare class ZDeviceStatusJsonRegistration {
    callback: ZDeviceStatusJsonCallback;
    nonceString: String | undefined;
    constructor(callback: ZDeviceStatusJsonCallback, nonceString: String | undefined);
    deregister(): void;
}
//# sourceMappingURL=ZDeviceStatusJsonRegistration.d.ts.map