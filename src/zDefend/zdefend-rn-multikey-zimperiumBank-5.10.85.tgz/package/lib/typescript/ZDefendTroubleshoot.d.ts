import { ZLogType } from './enums/ZLogType';
/**
 * ZDefendTroubleshootDetailsCallback is the handler for receiving the troubleshoot details get request.
 *
 * A block implementing this interface is required for receiving device status updates. See ZDefendTroubleshoot#getTroubleshootDetails.
 *
 * @param troubleshootDetails - the key/value pair set of details.
 */
type ZDefendTroubleshootDetailsCallback = (troubleshootDetails: object) => void;
/**
 * ZLogCallback is the handler for receiving the results from ZDefend#getLogs.
 *
 * A class implementing this interface is required for receiving the get logs events.
 *
 * @param messages the log messages for the requested type.
 */
type ZLogCallback = (messages: string) => void;
/**
 * ZLogCallback is the handler for receiving the results from ZDefend#getLogs.
 *
 * A class implementing this interface is required for receiving the get logs events.
 *
 * @param messages the log messages for the requested type.
 * @param requestType the type of logs requested, use ZLOG_ALL to request all logs, see ZLogType.
 */
type ZLogTypeCallback = (messages: string, requestType: ZLogType) => void;
/**
 * ZDefendTroubleshoot is the troubleshooting api to aid in development and debugging.
 */
export declare class ZDefendTroubleshoot {
    /**
     * Request the device details to assist in troubleshooting.
     *
     * The device troubleshoot details request will asynchronously provide the details to the provided callback.
     *
     * @param callback - handler to be called asynchronously to deliver the troubleshoot details. See ZDefendTroubleshootDetailsCallback.
     */
    static getTroubleshootDetails({ callback }: {
        callback: ZDefendTroubleshootDetailsCallback;
    }): void;
    /**
    * Request the current NORMAL device ZLog contents.
    *
    * The device logs request will asynchronously provide the logs to the provided callback.
    *
    * @param callback - handler to be called asynchronously to deliver device logs. See ZLogCallback.
    */
    static getZLog({ callback }: {
        callback: ZLogCallback;
    }): void;
    /**
    * Request the current device ZLog contents for a specific ZLog type.
    *
    * The device logs request will asynchronously provide the logs to the provided callback.
    *
    * @param callback - handler to be called asynchronously to deliver device logs. See ZLogCallback.
    * @param requestType the type of logs requested, use ZLOG_ALL to request all logs, see ZLogType.
    */
    static getZLogWithRequestType({ requestType, callback }: {
        requestType: ZLogType;
        callback: ZLogTypeCallback;
    }): void;
}
export {};
//# sourceMappingURL=ZDefendTroubleshoot.d.ts.map