import { ZLoginError } from './enums/ZLoginError';
import { ZLoginStatus } from './enums/ZLoginStatus';
import { ZDefendPolicy } from './zdefend_policy/ZDefendPolicy';
import { ZDefendThreat } from './zdefend_threat/ZDefendThreat';
import { ZDeviceStatusCompressionType } from './enums/ZDeviceStatusCompressionType';
/**
 * The device status describing the ZDefend state when the status event occurred. See ZDeviceStatusCallback.
 *
 * The device status is updated when new policies are processed, device threats are generated and mitigated, and the device login status changes.
 *
 * The device status provides the base64 encoded status and the digital signature that can be used to verify the event authenticity.
 */
export declare class ZDeviceStatus {
    private _statusDate;
    private _deviceStatusBase64;
    private _deviceStatusBase64Signature;
    private _loginStatus;
    private _loginLastError;
    private _initialScanProgressPercentage;
    private _sdkVersion;
    private _deviceId;
    private _devicePolicies;
    private _allThreats;
    private _activeThreats;
    private _mitigatedThreats;
    private _activeNewThreats;
    private _mitigatedNewThreats;
    private _decodedStatus;
    private _threatTextExcluded;
    private _policyStatusExcluded;
    private _compressedDeviceStatusBase64;
    private _compressedDeviceStatusBase64Signature;
    private _compressionType;
    constructor(encodedStatus: string, priorStatus?: ZDeviceStatus);
    /**
     * @property deviceId -  unique device.
    */
    get deviceId(): string;
    /**
     * @property sdkVersion -  current ZDefend sdk version.
     */
    get sdkVersion(): string;
    /**
     * @property statusDate -  the device status generation time/date.
     */
    get statusDate(): Date;
    /**
     * @property deviceStatusBase64 - the base64 encoded device status. This is the base64 encoding of the json key/value pairs
     * describing this device status. The base64 string can be authenticated using the digital signature, see ZDeviceStatus#getBase64Signature.
     */
    get deviceStatusBase64(): string;
    /**
     * @property deviceStatusBase64Signature - the base64 device status digital signature. See ZDeviceStatus#getBase64.
     */
    get deviceStatusBase64Signature(): string;
    /**
     * @property loginStatus - the login status.
     */
    get loginStatus(): ZLoginStatus;
    /**
     * @property initialScanProgressPercentage - Get the initial scan progress percentage. 0 as the scan is starting,
     * 1 to 99 of the current scan progress percentage, 100 when the scan is complete. The initial scan starts immediately after ZDefend login.
     * .
     */
    get initialScanProgressPercentage(): number;
    /**
     * @property devicePolicies - a list of ZDefendPolicy objects.
     */
    get devicePolicies(): ZDefendPolicy[];
    /**
     * @property allThreats - the threats in the device device status. The threat list will include all new, active and previous threats including mitigated threats.
     */
    get allThreats(): ZDefendThreat[];
    /**
     * @property activeThreats - the  non-mitigated only threat list of the ZDeviceStatus event.
     */
    get activeThreats(): ZDefendThreat[];
    /**
     * @property mitigatedThreats - the mitigated only threat list of the ZDeviceStatus event.
     */
    get mitigatedThreats(): ZDefendThreat[];
    /**
     * @property activeNewThreats - the new non-mitigated threat list since the prior ZDeviceStatus event.
     */
    get activeNewThreats(): ZDefendThreat[];
    /**
     * @property mitigatedNewThreats - the new mitigated threat list since the prior ZDeviceStatus event.
     */
    get mitigatedNewThreats(): ZDefendThreat[];
    /**
     * @property loginLastError - the last login error. See ZLoginError.
     *          LOGIN_ERROR_LOGGED_IN is returned when loginStatus is LOGGED_IN.
     */
    get loginLastError(): ZLoginError;
    /**
    * @property threatTextExcluded - Get the text excluded configuration state for this device status event. See ZDeviceStatus#excludeThreatText(boolean).
    * Property is  true if the localized text has been excluded for this event.
    */
    get threatTextExcluded(): boolean;
    /**
     * @property policyStatusExcluded - Get the policy status excluded configuration state for this device status event. See ZDeviceStatus#excludePolicyStatus(boolean).
     * Property is true if the policy status has been excluded for this event.
     */
    get policyStatusExcluded(): boolean;
    /**
     * @property compressedDeviceStatusBase64 - the compressed base64 encoded device status. This is the base64 encoding of the json key/value pairs
     * describing this device status. The base64 string can be authenticated using the digital signature, see ZDeviceStatus#getBase64Signature.
     * See #getCompressionType() for how this data is compressed.
     * This property is nil if compression is set to COMPRESSION_TYPE_NONE. See #setCompressionType(CompressionType).
     * Value is nil if
     */
    get compressedDeviceStatusBase64(): String | undefined;
    /**
    * @property compressedDeviceStatusBase64Signature - the compressed base64 device status digital signature. See ZDeviceStatus#compressedDeviceStatusBase64.
    * This property is nil if compression is set to COMPRESSION_TYPE_NONE. See #setCompressionType(CompressionType).
    */
    get compressedDeviceStatusBase64Signature(): String | undefined;
    /**
     * Get the compression type used for this device status event. See ZDeviceStatus#setCompressionType(ZDeviceStatusCompressionType).
     * @return the data compression type used for #getCompressedBase64()}. COMPRESSION_TYPE_NONE is returned if compressed is not enabled.
     */
    get compressionType(): ZDeviceStatusCompressionType;
    private _generateLastLoginError;
    private _generateDevicePolicies;
    private _generateThreats;
    toString(): string;
    /**
     * Configure the device status to exclude localized text from device status updates. Setting true will reduce the device status event size.
     * This configuration is persistent for the current login.
     * @param excludeText true to exclude localized text from status updates. The default configuration is false.
     */
    static setExcludeThreatText(excludeText: boolean): void;
    /**
     * Configure the device status to exclude policy status from device status updates. Setting true will reduce the device status event size.
     * This configuration is persistent for the current login.
     * @param excludePolicyStatus true to exclude policy status from status updates. The default configuration is false.
     */
    static setExcludePolicyStatus(excludePolicyStatus: boolean): void;
    /**
     * Configure the device status to produce compressed base64 device status. ZDeviceStatus#getCompressedBase64().
     * By default compression is disabled and the type is set to COMPRESSION_TYPE_NONE.
     * @param type the compression type use.
     */
    static setCompressionType(type: ZDeviceStatusCompressionType): void;
}
//# sourceMappingURL=ZDeviceStatus.d.ts.map