import { ZDefendPolicyType } from '../enums/ZDefendPolicyType';
/**
 * A ZDefend policy description.
 */
export declare class ZDefendPolicy {
    private _policyType;
    private _policyDownloadDate;
    private _policyHash;
    constructor(type: ZDefendPolicyType, date: Date, hash: string);
    /**
     * @property policyType - the current policy type.
     */
    get policyType(): ZDefendPolicyType;
    /**
     * @property policyDownloadDate - the policy download date and time.
     */
    get policyDownloadDate(): Date;
    /**
     * @property policyHash - the policy hash value that uniquely identifies the policy.
     */
    get policyHash(): string;
    /**
   * Generates a string representation of the ZDefendPolicy object.
   */
    toString(): string;
}
//# sourceMappingURL=ZDefendPolicy.d.ts.map