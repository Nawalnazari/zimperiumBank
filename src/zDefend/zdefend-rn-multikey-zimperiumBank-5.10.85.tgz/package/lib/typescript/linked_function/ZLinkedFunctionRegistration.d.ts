import type { ZLinkedFunctionEvent } from "./ZLinkedFunctionEvent";
/**
 * ZLinkedFunction is the interface for receiving linked function events.
 *
 * A class implementing this interface is required for receiving linked function events.
 * See ZDefend.registerLinkedFunction(String, ZLinkedFunction, ZLinkedFunction) for registering linked functions.
 *
 */
export type ZLinkedFunction = (event: ZLinkedFunctionEvent) => void;
export declare class ZLinkedFunctionRegistration {
    private _regId;
    private _label;
    private _linkedFunction;
    private _mitigateLinkedFunction;
    private _deregistered;
    constructor(regId: number | undefined, label: string, linkedFunction: ZLinkedFunction, mitigateLinkedFunction: ZLinkedFunction);
    get label(): string;
    get linkedFunction(): ZLinkedFunction;
    get mitigateLinkedFunction(): ZLinkedFunction;
    remove(): void;
    get deregistered(): boolean;
    get regId(): number | undefined;
    set regId(id: number | undefined);
}
//# sourceMappingURL=ZLinkedFunctionRegistration.d.ts.map