import type { ZDefendThreat } from "../zdefend_threat/ZDefendThreat";
import type { ZDeviceStatus } from "../ZDeviceStatus";
import type { ZLinkedFunctionEventType } from "../enums/ZLinkedFunctionEventType";
/**
 * ZLinkedFunctionEvent is class representing the a triggered linked function event. These events are passed to registered
 * linked function callbacks when a linked function event is triggered.
 * See ZDefend.registerLinkedFunction for registering linked functions.
 */
export declare class ZLinkedFunctionEvent {
    private _label;
    private _eventType;
    private _deviceStatus;
    private _relatedThreats;
    constructor(label: string, eventType: ZLinkedFunctionEventType, status: ZDeviceStatus, threats: ZDefendThreat[]);
    /**
     * Get the label for this ZLinkedFunction event.
     * @returns The event label.
     */
    get label(): string;
    /**
     * Get the EventType for this ZLinkedFunction event.
     * @returns The event type.
     */
    get eventType(): ZLinkedFunctionEventType;
    /**
     * Get the ZDeviceStatus for when this ZLinkedFunction event was generated.
     * @returns The device status for this event.
     */
    get deviceStatus(): ZDeviceStatus;
    /**
     * Get the list of related threats for this ZLinkedFunction event.
     * @returns The list of related threats.
     */
    get relatedThreats(): ZDefendThreat[];
    /**
     * Returns a string representation of the LinkedFunctionEvent object.
     * @returns The string representation.
     */
    toString(): string;
}
//# sourceMappingURL=ZLinkedFunctionEvent.d.ts.map