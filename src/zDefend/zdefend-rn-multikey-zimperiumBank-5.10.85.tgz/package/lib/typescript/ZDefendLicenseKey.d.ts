import { ZDefendLicenseKeyNames } from "./enums/ZDefendLicenseKeyNames";
export declare class ZDefendLicenseKey {
    static selectLicenseKey(name: ZDefendLicenseKeyNames): void;
}
//# sourceMappingURL=ZDefendLicenseKey.d.ts.map