import type { ZDeviceStatusCallback } from "./ZDefend";
export declare class ZDeviceStatusRegistration {
    callback: ZDeviceStatusCallback;
    constructor(callback: ZDeviceStatusCallback);
    deregister(): void;
}
//# sourceMappingURL=ZDeviceStatusRegistration.d.ts.map