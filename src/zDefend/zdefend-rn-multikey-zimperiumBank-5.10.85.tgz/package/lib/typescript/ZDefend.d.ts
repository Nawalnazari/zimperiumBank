import { ZDeviceStatus } from "./ZDeviceStatus";
import { ZDefendThreat } from "./zdefend_threat/ZDefendThreat";
import type { ZLinkedFunctionRegistration, ZLinkedFunction } from "./linked_function/ZLinkedFunctionRegistration";
import type { ZDeviceStatusRegistration } from "./ZDeviceStatusRegistration";
import type { ZDeviceStatusJsonRegistration } from "./ZDeviceStatusJsonRegistration";
import { DelayedRulesCompliance } from "./enums/DelayedRulesCompliance";
export type ErrorCallbackFunction = (error: string) => void;
/**
 * ZDeviceStatusCallback is the handler for receiving device status updates.
 *
 * A block implementing this interface is required for receiving device status updates. SeeZDefend#addDeviceStatusCallback:ZDeviceStatusCallback for registering the custom handler implementation.
 *
 * @param deviceStatus the current device status. See interface ZDeviceStatus.
 */
export type ZDeviceStatusCallback = (deviceStatus: ZDeviceStatus) => void;
/**
 * ZDeviceStatusJsonCallback is the handler for receiving device status json updates.
 
 * A block implementing this interface is required for receiving device status json updates. See ZDefend#addDeviceStatusJsonCallback:ZDeviceStatusJsonCallback for registering the custom handler implementation.
*
*@param deviceStatusJsonBase64 the base64 encoded device status json string.
*@param base64Signature the base64 device status digital signature.
*/
export type ZDeviceStatusJsonCallback = (deviceStatusJsonBase64: String, base64Signature: String) => void;
/**
 * ZLinkedFunction is the interface for receiving linked function events.
 *
 * A class implementing this interface is required for receiving linked function events. See ZDefend#registerLinkedFunction for registering linked functions.
 *
 * @param label the linked function register label.
 * @param threat the threat that triggered the linked function, or null when not triggered by a threat.
 */
export type ZLinkedFunctionCallback = (label: string, threat: ZDefendThreat) => void;
/**
 * ZDefend is the main interface point for information and control.
 *
 * All requests and commands occur asynchronous and passing handlers is required to obtain status and details.
 */
export declare class ZDefend {
    /**
    * Register a handler that will be called for updates to the ZDefend device status.
    *
    * ZDeviceStatusRegistration#deregister must be called before the deviceStatusCallback goes out of scope.
    *
    * You will get the current ZDeviceStatusCallback immediately returned when adding the callback.
    *
    * Device status callbacks are asynchronous for the following events: login status change, new threats, mitigated threats, policy updates.
    *
    * @param callback - handler to be called for ZDefend device status updates. See ZDeviceStatusCallback.
    * @return the registration object that can be used for de-registering the handeler. See ZDeviceStatusRegistration.
    */
    static addDeviceStatusCallback({ deviceStatusCallback }: {
        deviceStatusCallback: ZDeviceStatusCallback;
    }): ZDeviceStatusRegistration;
    /**
     * Register a handler that will be called for updates to the ZDefend device status.
     * You will get the current ZDeviceStatusJsonCallback immediately returned when adding the callback.
     * Device status callbacks are asynchronous for the following events: login status change, new threats, mitigated threats, policy updates.
     * @param deviceStatusJsonCallback - handler to be called for ZDefend device status json updates. See ZDeviceStatusJsonCallback.
     *  the registration object that can be used for de-registering the handler. See ZDeviceStatusJsonRegistration.
     */
    static addDeviceStatusJsonCallback({ deviceStatusJsonCallback }: {
        deviceStatusJsonCallback: ZDeviceStatusJsonCallback;
    }): ZDeviceStatusJsonRegistration;
    /**
     * Set the SDK nonce string and register a device status json callback for this nonce.
     * The set nonce string will be included in the json details for all future ZDeviceStatus events
     * with the json key "nonce".
     * After the nonce string is set, a new ZDeviceStatus event will be generated and delivered via the callback.
     * The provided callback will only be called for device status events that contain the set nonceString. If the nonceString is
     * later changed, then the future device status events will not be delivered to the callback.
     * @param nonceString the nonce string value.
     * @param deviceStatusJsonCallback the device status json callback to deliver any device status with nonceString.
     * @return the registration object that can be used for de-registering the handler. See {@link ZDeviceStatusJsonRegistration}.
     * @throws Error if the nonceString is empty.
     */
    static setNonceWithCallback({ nonceString, deviceStatusJsonCallback }: {
        nonceString: String;
        deviceStatusJsonCallback: ZDeviceStatusJsonCallback;
    }): ZDeviceStatusJsonRegistration;
    /**
    * Register a sdk linked function that will run when a linked function with the label string is triggered.
    * <p/>
    * Linked functions are triggered from ZDefend events, e.g. a new Threat. Registering a linked function allows
    * custom actions to execute for triggered events.
    * <p/>
    * @param label The linked function trigger label.
    * @param linkedFunction The custom action function to run for the triggered event.
    * @return the registration object that can be used for de-registering the linked function, see {@link ZLinkedFunctionRegistration}.
    */
    static registerLinkedFunction({ label, linkedFunctionCallback }: {
        label: string;
        linkedFunctionCallback: ZLinkedFunctionCallback;
    }): void;
    /**
     * Remove this linked function registration.
     *
     * @param registrar - LinkedFunctionRegistrar object to be removed.
     */
    static removeLinkedFunction(registrar: ZLinkedFunctionRegistration): void;
    /**
     * Register sdk linked functions that will run when a linked function with the label string is triggered.
     * Linked functions are triggered from ZDefend events, e.g. a new Threat. Registering a linked function allows custom actions to execute for triggered events.
     * Each registered linked function is triggered only when a trigger event label matches the registered linked function label.
     * The registered actionFunction will be called one-time only when the first trigger event with a matching label becomes active.
     * Later trigger events after the first will not invoke the actionFunction unless all trigger events with the matching label have
     * been mitigated. If there is an active trigger event with matching label at the time the liked function is registered, the
     * actionFunction will be immediately called.
     * The registered mitigateFunction will be called one-time only after the mitigation of every trigger event with a matching label.
     * @param label - The linked function trigger label.
     * @param linkedFunction - The custom action function to run when a triggered event first becomes active.
     * @param mitigateLinkedFunction - The custom action function to run for the triggered event.
     *
     * @returns the registration object that can be used for de-registering the linked function, see ZLinkedFunctionRegistration.
     */
    static registerLinkedFunctionV2(label: string, linkedFunction: ZLinkedFunction, mitigateLinkedFunction: ZLinkedFunction): ZLinkedFunctionRegistration;
    /**
    * Set tracking id tags for threats and device events.
    * Once id tags are set, they will be associated with device events and threats.
    * Setting an id to nil or empty string will remove the tracking ID.
    * <p/>
    * @param tag1: tag1 string
    * @param tag2: tag2 string
    * @throws NSException is thrown if any tracking ID length is greater than 128 characters.
    */
    static setTrackingIds({ tag1, tag2, errorCallback }: {
        tag1: string;
        tag2: string;
        errorCallback: ErrorCallbackFunction;
    }): void;
    /**
    * Request the device check for ZDefend updates.
    *
    * The update check occurs asynchronous where any ZDefend updates will generate a ZDeviceStatusCallback. See ZDefend#addDeviceStatusCallback(ZDeviceStatusCallback}.
    */
    static checkForUpdates(): void;
    /**
     * Set the SDK nonce string.
     * If the nonce string is set, the value will be included in the json details for all ZDeviceStatus events
     * with the json key "nonce". The nonce string can be cleared by setting an empty string.
     * After the nonce string is set with a non-empty value, a new ZDeviceStatus event will automatically be generated,
     * see ZDefend.addDeviceStatusCallback().
     * @param {string} nonce - the nonce string value or an empty string.
     */
    static setNonce(nonce: String): void;
    /**
     * Activate rules that were delayed for compliance requirements.
     *
     * This method should be called on each app start when delayed activation is required.
     * Calling this method multiple times is safe.
     *
     * @param complianceType - the type of compliance mode to activate.
     */
    static activateDelayedRules(complianceType: DelayedRulesCompliance): void;
}
//# sourceMappingURL=ZDefend.d.ts.map