import { ZLocalNetworkAuthorizationType } from './enums/ZLocalNetworkAuthorizationType';
export type ZLocalNetworkAuthorizationCallback = (deviceStatus: ZLocalNetworkAuthorizationType) => void;
export declare class ZLocalNetworkPermission {
    static requestLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback): void;
    static checkLocalNetworkAuthorization(authorizationCallback: ZLocalNetworkAuthorizationCallback): void;
}
//# sourceMappingURL=ZLocalNetworkPermission.d.ts.map